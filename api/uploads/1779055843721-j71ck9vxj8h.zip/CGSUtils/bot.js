require('dotenv').config();
const { Client, GatewayIntentBits, ActivityType, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Ticket System Data Management
class TicketManager {
    constructor() {
        this.ticketsFilePath = path.join(__dirname, 'data', 'tickets.json');
        this.activeTickets = new Map();
        this.ensureDataDirectory();
        this.loadTickets();
    }

    ensureDataDirectory() {
        const dataDir = path.join(__dirname, 'data');
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
            console.log('Created data directory for ticket persistence');
        }
    }

    loadTickets() {
        try {
            if (!fs.existsSync(this.ticketsFilePath)) return;
            
            const data = JSON.parse(fs.readFileSync(this.ticketsFilePath, 'utf8'));
            const ticketsData = data.activeTickets || {};
            
            // Restore tickets and auto-close timeouts
            for (const [channelId, ticketData] of Object.entries(ticketsData)) {
                this.activeTickets.set(channelId, ticketData);
                this.restoreAutoCloseTimeout(channelId, ticketData);
            }
            
            console.log(`Loaded ${this.activeTickets.size} active tickets from persistent storage`);
        } catch (error) {
            console.error('Error loading tickets:', error);
            this.activeTickets = new Map();
        }
    }

    restoreAutoCloseTimeout(channelId, ticketData) {
        if (!ticketData.closeRequest?.autoCloseAt) return;
        
        const timeLeft = ticketData.closeRequest.autoCloseAt - Date.now();
        const closeHandler = () => {
            const handler = client.handlers.get('close_ticket');
            if (handler?.autoCloseTicket) {
                handler.autoCloseTicket(client, channelId, ticketData, '1333307663421014016');
            }
        };

        if (timeLeft > 0) {
            ticketData.autoCloseTimeout = setTimeout(closeHandler, timeLeft);
            console.log(`Restored auto-close timeout for ticket ${channelId} (${Math.ceil(timeLeft / 1000 / 60)} minutes remaining)`);
        } else {
            setTimeout(closeHandler, 5000); // Give bot time to start up
            console.log(`Ticket ${channelId} will be auto-closed immediately (timeout expired)`);
        }
    }

    saveTickets() {
        try {
            const ticketsData = {
                lastUpdated: Date.now(),
                activeTickets: {}
            };

            for (const [channelId, ticketData] of this.activeTickets.entries()) {
                const dataToSave = { ...ticketData };
                delete dataToSave.autoCloseTimeout; // Remove timeout reference
                
                // Add auto-close timestamp if there's a close request
                if (ticketData.closeRequest && ticketData.autoCloseTimeout) {
                    dataToSave.closeRequest = {
                        ...ticketData.closeRequest,
                        autoCloseAt: Date.now() + 14400000 // Current time + 4 hours
                    };
                }
                
                ticketsData.activeTickets[channelId] = dataToSave;
            }

            fs.writeFileSync(this.ticketsFilePath, JSON.stringify(ticketsData, null, 2));
        } catch (error) {
            console.error('Error saving tickets:', error);
        }
    }

    addTicket(channelId, ticketData) {
        this.activeTickets.set(channelId, ticketData);
        this.saveTickets();
        console.log(`Added ticket ${channelId} to persistent storage`);
    }

    updateTicket(channelId, ticketData) {
        if (this.activeTickets.has(channelId)) {
            this.activeTickets.set(channelId, ticketData);
            this.saveTickets();
        }
    }

    removeTicket(channelId) {
        const ticketData = this.activeTickets.get(channelId);
        if (!ticketData) return;
        
        // Clear any active timeouts
        if (ticketData.autoCloseTimeout) {
            clearTimeout(ticketData.autoCloseTimeout);
        }
        
        this.activeTickets.delete(channelId);
        this.saveTickets();
        console.log(`Removed ticket ${channelId} from persistent storage`);
    }

    getTicket(channelId) {
        return this.activeTickets.get(channelId);
    }

    getAllTickets() {
        return this.activeTickets;
    }

    startAutoSave() {
        setInterval(() => this.saveTickets(), 5 * 60 * 1000); // 5 minutes
        console.log('Started auto-save for ticket data (every 5 minutes)');
    }
}

// Generic handler loader
function loadHandlers(folderName) {
    const handlers = new Collection();
    const handlersPath = path.join(__dirname, 'handlers', folderName);
    
    if (!fs.existsSync(handlersPath)) return handlers;
    
    const handlerFiles = fs.readdirSync(handlersPath).filter(file => file.endsWith('.js'));
    
    for (const file of handlerFiles) {
        const filePath = path.join(handlersPath, file);
        const handler = require(filePath);
        
        if ('name' in handler && 'execute' in handler) {
            handlers.set(handler.name, handler);
            console.log(`Loaded ${folderName} handler: ${handler.name}`);
        } else {
            console.log(`[WARNING] The handler at ${filePath} is missing required properties.`);
        }
    }
    
    return handlers;
}

// Load commands
function loadCommands() {
    const commands = new Collection();
    const commandsPath = path.join(__dirname, 'commands');
    
    if (!fs.existsSync(commandsPath)) return commands;
    
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        
        // Clear require cache to reload commands
        delete require.cache[require.resolve(filePath)];
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            commands.set(command.data.name, command);
            console.log(`Loaded command: ${command.data.name}`);
        } else {
            console.log(`[WARNING] The command at ${filePath} is missing required properties.`);
        }
    }
    
    return commands;
}

// Create client and initialize
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// Initialize client collections and managers
client.commands = loadCommands();
client.handlers = new Collection([
    ...loadHandlers('selectMenus'),
    ...loadHandlers('buttons')
]);
client.modalHandler = require('./handlers/modalHandler');
client.ticketManager = new TicketManager();
client.activeTickets = client.ticketManager.getAllTickets(); // Backwards compatibility
client.tempCloseData = new Map();

// Manual command refresh function for problematic guilds
async function forceRefreshGuildCommands(guildId) {
    try {
        const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);
        
        console.log(`Force refreshing commands for guild ${guildId}...`);
        
        // Get all commands that should be in this guild
        const commandsToRegister = [];
        client.commands.forEach(command => {
            if (command.guildSpecific && command.targetGuild === guildId) {
                commandsToRegister.push(command.data.toJSON());
            }
        });
        
        // Clear existing guild commands first
        await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), { body: [] });
        console.log(`Cleared existing commands for guild ${guildId}`);
        
        // Wait a moment
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Re-register commands
        if (commandsToRegister.length > 0) {
            await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), { body: commandsToRegister });
            console.log(`Re-registered ${commandsToRegister.length} commands for guild ${guildId}`);
        }
        
        // Force cache refresh
        const guild = client.guilds.cache.get(guildId);
        if (guild) {
            await guild.commands.fetch();
            console.log(`Refreshed command cache for ${guild.name}`);
        }
        
        return true;
    } catch (error) {
        console.error(`Error force refreshing commands for guild ${guildId}:`, error);
        return false;
    }
}

// Full resync function - clears all commands and re-registers them
async function fullCommandResync(message) {
    const statusMessage = await message.reply('🔄 Starting command resync...');
    
    try {
        const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);
        
        // Step 1: Clear all existing commands
        await statusMessage.edit('🗑️ Clearing all existing commands...');
        
        // Clear global commands
        await rest.put(Routes.applicationCommands(client.user.id), { body: [] });
        console.log('Cleared all global commands');
        
        // Clear guild-specific commands for the problematic guild
        const problemGuildId = '1396705648208646235';
        await rest.put(Routes.applicationGuildCommands(client.user.id, problemGuildId), { body: [] });
        console.log(`Cleared all guild commands for ${problemGuildId}`);
        
        // Step 2: Reload commands from files
        await statusMessage.edit('📂 Reloading commands from files...');
        client.commands = loadCommands();
        
        // Step 3: Wait a moment for Discord's API
        await statusMessage.edit('⏳ Waiting for Discord API...');
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Step 4: Re-register all commands
        await statusMessage.edit('📝 Re-registering commands...');
        
        // Separate commands into global and guild-specific
        const globalCommands = [];
        const guildCommands = [];
        
        client.commands.forEach(command => {
            const commandData = command.data.toJSON();
            
            if (command.guildSpecific && command.targetGuild === problemGuildId) {
                guildCommands.push(commandData);
            } else {
                globalCommands.push(commandData);
            }
        });
        
        // Register global commands
        if (globalCommands.length > 0) {
            await rest.put(Routes.applicationCommands(client.user.id), { body: globalCommands });
            console.log(`Re-registered ${globalCommands.length} global commands`);
        }
        
        // Register guild-specific commands
        if (guildCommands.length > 0) {
            await rest.put(
                Routes.applicationGuildCommands(client.user.id, problemGuildId), 
                { body: guildCommands }
            );
            console.log(`Re-registered ${guildCommands.length} guild-specific commands`);
        }
        
        // Step 5: Force cache refresh
        await statusMessage.edit('🔄 Refreshing command cache...');
        const guild = client.guilds.cache.get(problemGuildId);
        if (guild) {
            await guild.commands.fetch();
        }
        
        // Success message
        const totalCommands = globalCommands.length + guildCommands.length;
        await statusMessage.edit(`✅ Command resync completed successfully!\n📊 Reloaded ${totalCommands} commands (${globalCommands.length} global, ${guildCommands.length} guild-specific)\n⚠️ Commands may take up to 1 hour to fully propagate.`);
        
        console.log(`Full command resync completed by ${message.author.tag}`);
        
    } catch (error) {
        console.error('Error during command resync:', error);
        await statusMessage.edit(`❌ Command resync failed: ${error.message}\nCheck console for details.`);
    }
}

// Updated register slash commands function
async function registerSlashCommands() {
    try {
        const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);
        
        // Separate commands into global and guild-specific
        const globalCommands = [];
        const guildCommands = [];
        const problemGuildId = '1396705648208646235';
        
        client.commands.forEach(command => {
            const commandData = command.data.toJSON();
            
            if (command.guildSpecific && command.targetGuild === problemGuildId) {
                guildCommands.push(commandData);
                console.log(`Preparing guild-specific command: ${command.data.name} for guild ${problemGuildId}`);
            } else {
                globalCommands.push(commandData);
                console.log(`Preparing global command: ${command.data.name}`);
            }
        });
        
        // Register global commands
        if (globalCommands.length > 0) {
            console.log(`Started refreshing ${globalCommands.length} global application (/) commands.`);
            await rest.put(Routes.applicationCommands(client.user.id), { body: globalCommands });
            console.log(`Successfully registered ${globalCommands.length} global application (/) commands.`);
        }
        
        // Register guild-specific commands for the problematic server
        if (guildCommands.length > 0) {
            console.log(`Started refreshing ${guildCommands.length} guild-specific commands for ${problemGuildId}.`);
            await rest.put(
                Routes.applicationGuildCommands(client.user.id, problemGuildId), 
                { body: guildCommands }
            );
            console.log(`Successfully registered ${guildCommands.length} guild-specific commands for ${problemGuildId}.`);
        }
        
        // Force refresh the problematic guild's commands (clear cache)
        try {
            console.log(`Force-refreshing command cache for guild ${problemGuildId}...`);
            const guild = client.guilds.cache.get(problemGuildId);
            if (guild) {
                await guild.commands.fetch();
                console.log(`Successfully refreshed command cache for ${guild.name}`);
            }
        } catch (error) {
            console.error('Error refreshing guild command cache:', error);
        }
        
    } catch (error) {
        console.error('Error refreshing commands:', error);
        
        // Fallback: Try to register just the claim command for the problematic guild
        try {
            console.log('Attempting fallback registration for claim command...');
            const claimCommand = client.commands.get('claim');
            if (claimCommand) {
                const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);
                await rest.put(
                    Routes.applicationGuildCommands(client.user.id, '1396705648208646235'),
                    { body: [claimCommand.data.toJSON()] }
                );
                console.log('Fallback registration successful for claim command');
            }
        } catch (fallbackError) {
            console.error('Fallback registration also failed:', fallbackError);
        }
    }
}

// Bot ready event
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    
    // Set bot status
    client.user.setPresence({
        status: 'online',
        activities: [{
            name: '[CGST JSv1.2] Ready!',
            type: ActivityType.Playing
        }]
    });
    
    console.log('Status set to online with activity: [CGST JSv1] Ready!');
    client.ticketManager.startAutoSave();
    
    // Register slash commands
    await registerSlashCommands();
    
    // Additional force refresh for the problematic guild after a delay
    setTimeout(async () => {
        const problemGuildId = '1396705648208646235';
        console.log(`Performing additional refresh for guild ${problemGuildId}...`);
        await forceRefreshGuildCommands(problemGuildId);
    }, 10000); // Wait 10 seconds after bot is ready
});

// Message handler for text commands
client.on('messageCreate', async message => {
    // Ignore bot messages
    if (message.author.bot) return;
    
    // Check for !resync command
    if (message.content.toLowerCase().startsWith('!resync')) {
        // Check if user has the required role
        const requiredRoleId = '1396877857220988978';
        const member = message.member;
        
        if (!member) {
            return message.reply('❌ This command can only be used in a server.');
        }
        
        if (!member.roles.cache.has(requiredRoleId)) {
            return message.reply('❌ You do not have permission to use this command.');
        }
        
        // Proceed with resync
        await fullCommandResync(message);
    }
});

// Unified interaction handler
const interactionHandlers = {
    async chatInputCommand(interaction) {
        const command = client.commands.get(interaction.commandName);
        if (!command) {
            console.error(`No command matching ${interaction.commandName} was found.`);
            return;
        }
        await command.execute(interaction);
    },

    async modalSubmit(interaction) {
        // Handle ticket close modals
        if (interaction.customId.startsWith('close_reason_')) {
            const closeHandler = client.handlers.get('close_ticket');
            if (closeHandler?.handleModalSubmit) {
                return await closeHandler.handleModalSubmit(interaction);
            }
        }
        await client.modalHandler.handleModal(interaction);
    },

    async stringSelectMenu(interaction) {
        const handler = client.handlers.get(interaction.customId);
        if (!handler) {
            console.error(`No select menu handler matching ${interaction.customId} was found.`);
            return;
        }
        await handler.execute(interaction);
    },

    async button(interaction) {
        const handlerName = this.getButtonHandlerName(interaction.customId);
        const handler = client.handlers.get(handlerName);
        
        if (!handler) {
            console.error(`No button handler matching ${handlerName} was found for customId: ${interaction.customId}`);
            return;
        }
        await handler.execute(interaction);
    },

    getButtonHandlerName(customId) {
        const buttonMappings = [
            'claim_ticket_', 'close_ticket_', 'confirm_close_',
            'deny_close_', 'cancel_close_'
        ];
        
        for (const prefix of buttonMappings) {
            if (customId.startsWith(prefix)) {
                return prefix.slice(0, -1); // Remove trailing underscore
            }
        }
        
        // For other button types, try to extract base name
        return customId.includes('_') 
            ? customId.split('_').slice(0, 2).join('_')
            : customId;
    }
};

// Main interaction handler
client.on('interactionCreate', async interaction => {
    try {
        const handlerMap = {
            isChatInputCommand: 'chatInputCommand',
            isModalSubmit: 'modalSubmit',
            isStringSelectMenu: 'stringSelectMenu',
            isButton: 'button'
        };

        for (const [checkMethod, handlerMethod] of Object.entries(handlerMap)) {
            if (interaction[checkMethod]()) {
                await interactionHandlers[handlerMethod](interaction);
                return;
            }
        }
    } catch (error) {
        console.error('Error executing interaction:', error);
        const errorMessage = 'There was an error while processing your request!';
        
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: errorMessage, ephemeral: true });
        } else {
            await interaction.reply({ content: errorMessage, ephemeral: true });
        }
    }
});

// Graceful shutdown handling
function gracefulShutdown(signal) {
    console.log(`\nReceived ${signal}. Saving ticket data before shutdown...`);
    client.ticketManager.saveTickets();
    console.log('Ticket data saved. Shutting down...');
    process.exit(0);
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// Error handling
client.on('error', (error) => {
    console.error('Client error:', error);
});

// Login to Discord
client.login(process.env.BOT_TOKEN);
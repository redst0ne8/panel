const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, PermissionFlagsBits, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    async handleModal(interaction) {
        if (interaction.customId === 'makepanel_modal') {
            await this.handleMakePanelModal(interaction);
        } else if (interaction.customId === 'makepanel_channel_modal') {
            await this.handleChannelSelectionModal(interaction);
        } else if (interaction.customId === 'ticket_types_modal') {
            // Import the sendpanel command to handle the ticket types modal
            const sendpanelCommand = require('../commands/sendpanel');
            await sendpanelCommand.handleTicketTypesModal(interaction);
        } else if (interaction.customId?.startsWith('close_reason_')) {
            await this.handleCloseReason(interaction);
        }
    },

    async handleMakePanelModal(interaction) {
        // Extract values from modal
        const title = interaction.fields.getTextInputValue('embed_title') || null;
        const description = interaction.fields.getTextInputValue('embed_description') || null;
        const author = interaction.fields.getTextInputValue('embed_author') || null;
        const thumbnail = interaction.fields.getTextInputValue('embed_thumbnail') || null;
        const image = interaction.fields.getTextInputValue('embed_image') || null;

        // Validate URLs if provided
        const urlRegex = /^https?:\/\/.+/i;
        
        if (thumbnail && !urlRegex.test(thumbnail)) {
            return await interaction.reply({ 
                content: '❌ Invalid thumbnail URL. Please provide a valid HTTP/HTTPS URL.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }
        
        if (image && !urlRegex.test(image)) {
            return await interaction.reply({ 
                content: '❌ Invalid image URL. Please provide a valid HTTP/HTTPS URL.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }

        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(0x0099ff)
            .setTimestamp();

        // Add properties if provided
        if (title) embed.setTitle(title);
        if (description) embed.setDescription(description);
        if (author) embed.setAuthor({ name: author });
        if (thumbnail) embed.setThumbnail(thumbnail);
        if (image) embed.setImage(image);
        embed.setFooter({ text: "CoasterTickets System" })

        // Check if embed has any content
        if (!title && !description && !author && !thumbnail && !image) {
            return await interaction.reply({ 
                content: '❌ Please provide at least one field for the embed.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }

        // Store embed data temporarily
        if (!interaction.client.tempEmbedData) {
            interaction.client.tempEmbedData = new Map();
        }
        interaction.client.tempEmbedData.set(interaction.user.id, embed);

        // Reply with instructions and show embed preview
        await interaction.reply({
            content: '✅ Embed created! Please use the `/sendpanel <channel_id>` command to send this embed to a specific channel.',
            embeds: [embed],
            flags: 64 // MessageFlags.Ephemeral
        });
    },

    async handleChannelSelectionModal(interaction) {
        const channelId = interaction.fields.getTextInputValue('channel_id');
        
        // Get stored embed data
        const embed = interaction.client.tempEmbedData?.get(interaction.user.id);
        
        if (!embed) {
            return await interaction.reply({ 
                content: '❌ Embed data not found. Please try the command again.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }

        try {
            // Get the channel
            const channel = await interaction.client.channels.fetch(channelId);
            
            if (!channel) {
                return await interaction.reply({ 
                    content: '❌ Channel not found. Please check the channel ID.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }

            // Check if channel is a text channel
            if (!channel.isTextBased()) {
                return await interaction.reply({ 
                    content: '❌ The specified channel is not a text channel.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }

            // Check if bot has permission to send messages in the channel
            const permissions = channel.permissionsFor(interaction.client.user);
            if (!permissions || !permissions.has(PermissionFlagsBits.SendMessages)) {
                return await interaction.reply({ 
                    content: '❌ I don\'t have permission to send messages in that channel.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }

            // Send the embed to the specified channel
            await channel.send({ embeds: [embed] });

            // Clean up temporary data
            interaction.client.tempEmbedData.delete(interaction.user.id);

            // Confirm success
            await interaction.reply({ 
                content: `✅ Embed panel successfully sent to <#${channelId}>!`, 
                flags: 64 // MessageFlags.Ephemeral
            });

        } catch (error) {
            console.error('Error sending embed:', error);
            
            // Clean up temporary data on error
            if (interaction.client.tempEmbedData) {
                interaction.client.tempEmbedData.delete(interaction.user.id);
            }
            
            let errorMessage = '❌ Failed to send embed. ';
            
            if (error.code === 10003) {
                errorMessage += 'Channel not found. Please check the channel ID.';
            } else if (error.code === 50013) {
                errorMessage += 'Missing permissions to send messages in that channel.';
            } else if (error.code === 50001) {
                errorMessage += 'Missing access to that channel.';
            } else {
                errorMessage += 'Please check the channel ID and try again.';
            }
            
            await interaction.reply({ 
                content: errorMessage, 
                flags: 64 // MessageFlags.Ephemeral
            });
        }
    },

    // Handle close reason modal
    async handleCloseReason(interaction) {
        const ticketChannelId = interaction.customId.split('_')[2];
        const closeReason = interaction.fields.getTextInputValue('close_reason') || 'No reason provided';
        
        const ticketData = interaction.client.activeTickets?.get(ticketChannelId);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ Ticket data not found.',
                ephemeral: true
            });
        }

        // Create confirmation embed
        const confirmEmbed = new EmbedBuilder()
            .setTitle('🔒 Confirm Ticket Closure')
            .setDescription('Are you sure you want to close this ticket?')
            .addFields([
                { name: '📋 Ticket Type', value: ticketData.ticketType, inline: true },
                { name: '👤 Ticket Owner', value: `<@${ticketData.userId}>`, inline: true },
                { name: '📝 Close Reason', value: closeReason, inline: false }
            ])
            .setColor('#ff6b6b')
            .setTimestamp();

        const confirmButton = new ButtonBuilder()
            .setCustomId(`confirm_close_${ticketChannelId}`)
            .setLabel('Confirm Close')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('✅');

        const cancelButton = new ButtonBuilder()
            .setCustomId(`cancel_close_${ticketChannelId}`)
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('❌');

        const buttonRow = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

        // Store the close reason temporarily
        if (!interaction.client.tempCloseData) {
            interaction.client.tempCloseData = new Map();
        }
        interaction.client.tempCloseData.set(ticketChannelId, {
            reason: closeReason,
            closedBy: interaction.user.id,
            closedByTag: interaction.user.tag
        });

        await interaction.reply({
            embeds: [confirmEmbed],
            components: [buttonRow],
            ephemeral: true
        });
    }
};
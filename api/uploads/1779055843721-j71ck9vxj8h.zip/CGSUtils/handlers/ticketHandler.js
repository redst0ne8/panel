const { PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'ticket_select',
    async execute(interaction) {
        // Defer the reply to prevent timeout
        await interaction.deferReply({ ephemeral: true });

        const selectedValue = interaction.values[0];
        const ticketLogChannelId = '1406342065486430350';
        const guild = interaction.guild;
        const user = interaction.user;

        // Get the original ticket type name from stored data
        const storedTicketTypes = interaction.client.ticketTypes?.get(guild.id) || [];
        let ticketTypeName = selectedValue.replace(/_/g, ' ');
        
        // Find the original ticket type name (case-sensitive)
        const originalTicketType = storedTicketTypes.find(type => 
            type.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') === selectedValue
        );
        
        if (originalTicketType) {
            ticketTypeName = originalTicketType;
        }

        // Generate a professional ticket ID
        const timestamp = Date.now().toString().slice(-6); // Last 6 digits of timestamp
        const userIdShort = user.id.slice(-4); // Last 4 digits of user ID
        const ticketId = `TKT-${timestamp}-${userIdShort}`;

        // Create professional channel name: "ticket-ID"
        const channelName = `ticket-${ticketId.toLowerCase()}`;

        try {
            // Check if user already has a ticket
            const existingChannel = guild.channels.cache.find(channel => 
                channel.type === ChannelType.GuildText &&
                channel.topic && channel.topic.includes(`Ticket created by ${user.id}`) &&
                channel.topic.includes('Status: Open')
            );

            if (existingChannel) {
                return await interaction.editReply({
                    content: `❌ You already have an open ticket: ${existingChannel}`
                });
            }

            // Create basic permission overwrites - no support roles can view by default
            const permissionOverwrites = [
                // Deny @everyone from seeing the channel
                {
                    id: guild.roles.everyone.id,
                    deny: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
                // Allow the ticket creator full access
                {
                    id: user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.UseExternalEmojis
                    ]
                },
                // Allow the bot full access
                {
                    id: interaction.client.user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.ManageMessages,
                        PermissionFlagsBits.ManageChannels,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.UseExternalEmojis
                    ]
                }
            ];

            // Add additional role permissions for admin/head support roles that should have access to all tickets
            const additionalSupportRoles = [
                // Add any additional role IDs here that should have access to all tickets
                // '1234567890123456789', // Example: Head Support role
                // '9876543210987654321', // Example: Admin role
            ];

            additionalSupportRoles.forEach(roleId => {
                const role = guild.roles.cache.get(roleId);
                if (role) {
                    permissionOverwrites.push({
                        id: roleId,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks,
                            PermissionFlagsBits.ManageMessages,
                            PermissionFlagsBits.AddReactions,
                            PermissionFlagsBits.UseExternalEmojis
                        ]
                    });
                    console.log(`✅ Granted access to additional role: ${role.name} (${role.id})`);
                }
            });

            console.log(`Permission overwrites configured for ${permissionOverwrites.length} entities`);

            // Create the ticket channel
            const ticketChannel = await guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                topic: `${ticketTypeName} | Ticket ID: ${ticketId} | Created by ${user.tag} (${user.id}) | Status: Open`,
                permissionOverwrites: permissionOverwrites,
                reason: `Ticket ${ticketId} created by ${user.tag} for ${ticketTypeName}`
            });

            console.log(`Ticket channel created: ${ticketChannel.name} (${ticketChannel.id})`);

            // Create welcome embed for the ticket
            const welcomeEmbed = new EmbedBuilder()
                .setTitle(`🎫 Ticket ${ticketId}`)
                .setDescription(`Hello ${user}, welcome to your support ticket!\n\nPlease describe your issue in detail. Use the buttons below or have an administrator use \`/addsupport\` to assign a support team.`)
                .addFields([
                    { name: '🆔 Ticket ID', value: `\`${ticketId}\``, inline: true },
                    { name: '📋 Ticket Type', value: ticketTypeName, inline: true },
                    { name: '👤 Created by', value: user.toString(), inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: '🔓 **UNCLAIMED**', inline: true },
                    { name: '👥 Assigned Support', value: '⏳ **None - Awaiting Assignment**', inline: true }
                ])
                .setColor('#ffff00') // Yellow for unassigned
                .setTimestamp()
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setFooter({ 
                    text: `Ticket System • Unassigned`,
                    iconURL: guild.iconURL({ dynamic: true })
                });

            // Create buttons
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannel.id}`)
                .setLabel('Claim Ticket')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('✋');

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannel.id}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            // Send welcome message to the ticket channel
            const welcomeMessage = await ticketChannel.send({
                content: `${user}\n\n**Ticket ID:** \`${ticketId}\`\n**Status:** Awaiting support team assignment`,
                embeds: [welcomeEmbed],
                components: [buttonRow]
            });

            console.log(`Welcome message sent to ticket channel`);

            // Store ticket data for reference
            if (!interaction.client.activeTickets) {
                interaction.client.activeTickets = new Map();
            }
            
            interaction.client.activeTickets.set(ticketChannel.id, {
                ticketId: ticketId,
                userId: user.id,
                username: user.username,
                userTag: user.tag,
                ticketType: ticketTypeName,
                supportSection: null, // Will be set when support is assigned
                supportRoleId: null, // Will be set when support is assigned
                createdAt: Date.now(),
                claimed: false,
                claimedBy: null,
                claimedById: null,
                channelName: channelName,
                welcomeMessageId: welcomeMessage.id,
                status: 'Open',
                assignedSupportRoles: [] // Track which support roles have been added
            });

            // Log ticket creation to log channel
            const logChannel = guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🎫 Ticket Created')
                    .setDescription(`**Ticket ID:** \`${ticketId}\``)
                    .addFields([
                        { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                        { name: '📋 Type', value: ticketTypeName, inline: true },
                        { name: '📺 Channel', value: ticketChannel.toString(), inline: true },
                        { name: '👥 Support Assignment', value: '⏳ **Awaiting Assignment**', inline: true },
                        { name: '🆔 Channel ID', value: `\`${ticketChannel.id}\``, inline: false }
                    ])
                    .setColor('#ffff00') // Yellow for unassigned
                    .setTimestamp()
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: `Ticket System • Unassigned` });

                await logChannel.send({ embeds: [logEmbed] });
            }

            await interaction.editReply({
                content: `✅ **Ticket Created Successfully!**\n\n**Ticket ID:** \`${ticketId}\`\n**Channel:** ${ticketChannel}\n**Status:** Awaiting support team assignment\n\n*Use \`/addsupport\` in the ticket channel to assign a support team.*`
            });

        } catch (error) {
            console.error('Error creating ticket:', error);
            console.error('Error details:', {
                code: error.code,
                message: error.message,
                stack: error.stack
            });
            
            let errorMessage = '❌ **Failed to create ticket.** ';
            
            if (error.code === 50013) {
                errorMessage += 'Missing permissions to create channels. Please ensure the bot has "Manage Channels" permission.';
            } else if (error.code === 50035) {
                errorMessage += 'Invalid channel configuration.';
            } else if (error.code === 50001) {
                errorMessage += 'Missing access permissions.';
            } else {
                errorMessage += `Please try again or contact an administrator. (Error: ${error.code || 'Unknown'})`;
            }
            
            await interaction.editReply({
                content: errorMessage
            });
        }
    }
};
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'deny_close',
    async execute(interaction) {
        const ticketChannelId = interaction.customId.split('_')[2];
        
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ Ticket data not found.',
                ephemeral: true
            });
        }

        // Check if user is the ticket owner
        if (interaction.user.id !== ticketData.userId) {
            return await interaction.reply({
                content: '❌ Only the ticket owner can deny closure.',
                ephemeral: true
            });
        }

        // Check if there's a pending close request
        if (!ticketData.closeRequest) {
            return await interaction.reply({
                content: '❌ No pending close request found.',
                ephemeral: true
            });
        }

        // Clear the auto-close timeout
        if (ticketData.autoCloseTimeout) {
            clearTimeout(ticketData.autoCloseTimeout);
            delete ticketData.autoCloseTimeout;
        }

        await interaction.deferReply();

        try {
            const requestedBy = await interaction.client.users.fetch(ticketData.closeRequest.requestedBy);

            // Create denial embed
            const denialEmbed = new EmbedBuilder()
                .setTitle('✅ Ticket Kept Open')
                .setDescription(`${interaction.user} has chosen to keep this ticket open.`)
                .addFields([
                    { name: '🔒 Close Request By', value: requestedBy.toString(), inline: true },
                    { name: '📝 Original Reason', value: ticketData.closeRequest.reason, inline: false },
                    { name: '✅ Status', value: 'Ticket will remain open for continued support.', inline: false }
                ])
                .setColor('#00ff00')
                .setTimestamp();

            // Edit the original message to remove buttons and show denial
            try {
                const originalMessage = await interaction.channel.messages.fetch(ticketData.closeRequest.confirmMessageId);
                await originalMessage.edit({
                    content: `~~${await interaction.client.users.fetch(ticketData.userId)}~~`,
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('🚫 Close Request Denied')
                            .setDescription('The ticket owner has chosen to keep this ticket open.')
                            .setColor('#ff0000')
                            .setTimestamp()
                    ],
                    components: []
                });
            } catch (error) {
                console.error('Error editing original message:', error);
            }

            // Send new status message
            await interaction.editReply({
                embeds: [denialEmbed]
            });

            // Clear the close request data and update persistent storage
            delete ticketData.closeRequest;
            interaction.client.ticketManager.updateTicket(ticketChannelId, ticketData);

            // Update ticket status back to unclaimed or claimed depending on previous state
            const statusMessage = ticketData.claimed 
                ? `🔓 Claimed by ${ticketData.claimedBy}`
                : '🔓 Unclaimed';

            // Try to update the original welcome message status
            try {
                const welcomeMessage = await interaction.channel.messages.fetch(ticketData.welcomeMessageId);
                const updatedEmbed = EmbedBuilder.from(welcomeMessage.embeds[0]);
                
                // Update the status field
                const fields = updatedEmbed.data.fields;
                const statusFieldIndex = fields.findIndex(field => field.name === '🏷️ Status');
                if (statusFieldIndex !== -1) {
                    fields[statusFieldIndex].value = statusMessage;
                }

                await welcomeMessage.edit({ embeds: [updatedEmbed] });
            } catch (error) {
                console.error('Error updating welcome message:', error);
            }

            console.log(`Close request denied for ticket ${ticketChannelId} by owner ${interaction.user.tag}`);

        } catch (error) {
            console.error('Error processing denial:', error);
            await interaction.editReply({
                content: '❌ An error occurred while processing the denial. The close request has been cancelled.'
            });
        }
    }
};
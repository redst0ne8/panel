const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'confirm_close',
    async execute(interaction) {
        const ticketChannelId = interaction.customId.split('_')[2];
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ Ticket data not found.',
                ephemeral: true
            });
        }

        // Check if user is the ticket owner
        if (interaction.user.id !== ticketData.userId) {
            return await interaction.reply({
                content: '❌ Only the ticket owner can confirm closure.',
                ephemeral: true
            });
        }

        // Clear the auto-close timeout if it exists
        if (ticketData.autoCloseTimeout) {
            clearTimeout(ticketData.autoCloseTimeout);
            delete ticketData.autoCloseTimeout;
        }

        await interaction.deferReply();

        try {
            const channel = interaction.channel;
            const guild = interaction.guild;

            // Create transcript before closing
            const messages = await channel.messages.fetch({ limit: 100 });
            const transcript = messages
                .reverse()
                .map(msg => {
                    const timestamp = new Date(msg.createdTimestamp).toLocaleString();
                    return `[${timestamp}] ${msg.author.tag}: ${msg.content}`;
                })
                .join('\n');

            // Log ticket closure
            const logChannel = guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const user = await interaction.client.users.fetch(ticketData.userId);
                const closedBy = interaction.user;

                const logEmbed = new EmbedBuilder()
                    .setTitle('🔒 Ticket Closed')
                    .setDescription('A ticket has been closed by the owner')
                    .addFields([
                        { name: '👤 Ticket Owner', value: `${user.tag} (${user.id})`, inline: true },
                        { name: '🔒 Closed By', value: `${closedBy.tag} (${closedBy.id})`, inline: true },
                        { name: '📋 Type', value: ticketData.ticketType, inline: true },
                        { name: '🆔 Ticket ID', value: ticketChannelId, inline: false },
                        { name: '🕐 Created At', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                        { name: '🔒 Closed At', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    ])
                    .setColor('#ff0000')
                    .setTimestamp()
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }));

                // Send transcript as a file if it exists
                if (transcript && transcript.length > 0) {
                    const Buffer = require('buffer').Buffer;
                    const transcriptBuffer = Buffer.from(transcript, 'utf8');
                    
                    await logChannel.send({
                        embeds: [logEmbed],
                        files: [{
                            attachment: transcriptBuffer,
                            name: `ticket-${ticketChannelId}-transcript.txt`
                        }]
                    });
                } else {
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

            // Remove from active tickets
            interaction.client.ticketManager.removeTicket(ticketChannelId);

            // Send final message
            await interaction.editReply({
                content: '✅ Ticket confirmed for closure. Channel will be deleted in 5 seconds...'
            });

            // Delete channel after delay
            setTimeout(async () => {
                try {
                    await channel.delete('Ticket closed and confirmed by owner');
                } catch (error) {
                    console.error('Error deleting ticket channel:', error);
                }
            }, 5000);

        } catch (error) {
            console.error('Error closing ticket:', error);
            await interaction.editReply({
                content: '❌ An error occurred while closing the ticket. Please contact an administrator.'
            });
        }
    }
};
const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'close_ticket',
    async execute(interaction) {
        const ticketChannelId = interaction.customId.split('_')[2];
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ Ticket data not found.',
                ephemeral: true
            });
        }

        // Check if user has support role
        const hasSupport = interaction.member.roles.cache.has(supportRoleId);
        
        if (!hasSupport) {
            return await interaction.reply({
                content: '❌ Only support staff can close tickets.',
                ephemeral: true
            });
        }

        // Show modal for close reason
        const modal = new ModalBuilder()
            .setCustomId(`close_reason_support_${ticketChannelId}`)
            .setTitle('Close Ticket');

        const reasonInput = new TextInputBuilder()
            .setCustomId('close_reason')
            .setLabel('Reason for closing')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Enter the reason for closing this ticket...')
            .setRequired(true)
            .setMaxLength(1000);

        const firstActionRow = new ActionRowBuilder().addComponents(reasonInput);
        modal.addComponents(firstActionRow);

        return await interaction.showModal(modal);
    },

    // Handle modal submissions
    async handleModalSubmit(interaction) {
        const [action, type, ticketChannelId] = interaction.customId.split('_').slice(1);
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        if (action !== 'reason') return;

        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ Ticket data not found.',
                ephemeral: true
            });
        }

        const closeReason = interaction.fields.getTextInputValue('close_reason') || 'No reason provided';
        
        await interaction.deferReply();

        try {
            return await this.closeTicketDirectly(interaction, ticketChannelId, ticketData, closeReason, ticketLogChannelId);
        } catch (error) {
            console.error('Error processing close request:', error);
            await interaction.editReply({
                content: '❌ An error occurred while processing the close request.'
            });
        }
    },

    // Close ticket directly
    async closeTicketDirectly(interaction, ticketChannelId, ticketData, closeReason, ticketLogChannelId) {
        const channel = interaction.channel;
        const guild = interaction.guild;

        // Create transcript
        const messages = await channel.messages.fetch({ limit: 100 });
        const transcript = messages
            .reverse()
            .map(msg => {
                const timestamp = new Date(msg.createdTimestamp).toLocaleString();
                return `[${timestamp}] ${msg.author.tag}: ${msg.content}`;
            })
            .join('\n');

        // Log ticket closure
        const logChannel = guild.channels.cache.get(ticketLogChannelId);
        if (logChannel) {
            const user = await interaction.client.users.fetch(ticketData.userId);

            const logEmbed = new EmbedBuilder()
                .setTitle('🔒 Ticket Closed')
                .setDescription('A ticket has been closed by support staff')
                .addFields([
                    { name: '👤 Ticket Owner', value: `${user.tag} (${user.id})`, inline: true },
                    { name: '🔒 Closed By', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                    { name: '📋 Type', value: ticketData.ticketType, inline: true },
                    { name: '📝 Reason', value: closeReason, inline: false },
                    { name: '🆔 Ticket ID', value: ticketChannelId, inline: false },
                    { name: '🕐 Created At', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                    { name: '🔒 Closed At', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                ])
                .setColor('#00ff00')
                .setTimestamp()
                .setThumbnail(user.displayAvatarURL({ dynamic: true }));

            if (transcript && transcript.length > 0) {
                const Buffer = require('buffer').Buffer;
                const transcriptBuffer = Buffer.from(transcript, 'utf8');
                
                await logChannel.send({
                    embeds: [logEmbed],
                    files: [{
                        attachment: transcriptBuffer,
                        name: `ticket-${ticketChannelId}-transcript.txt`
                    }]
                });
            } else {
                await logChannel.send({ embeds: [logEmbed] });
            }
        }

        // Remove from active tickets
        interaction.client.ticketManager.removeTicket(ticketChannelId);

        await interaction.editReply({
            content: '✅ Ticket closed successfully. Channel will be deleted in 5 seconds...'
        });

        setTimeout(async () => {
            try {
                await channel.delete('Ticket closed by support');
            } catch (error) {
                console.error('Error deleting ticket channel:', error);
            }
        }, 5000);
    },

    // Auto-close ticket after timeout
    async autoCloseTicket(client, ticketChannelId, ticketData, ticketLogChannelId) {
        try {
            const channel = client.channels.cache.get(ticketChannelId);
            if (!channel) return;

            const guild = channel.guild;

            // Create transcript
            const messages = await channel.messages.fetch({ limit: 100 });
            const transcript = messages
                .reverse()
                .map(msg => {
                    const timestamp = new Date(msg.createdTimestamp).toLocaleString();
                    return `[${timestamp}] ${msg.author.tag}: ${msg.content}`;
                })
                .join('\n');

            // Log auto-closure
            const logChannel = guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const user = await client.users.fetch(ticketData.userId);
                const requestedBy = await client.users.fetch(ticketData.closeRequest.requestedBy);

                const logEmbed = new EmbedBuilder()
                    .setTitle('🤖 Ticket Auto-Closed')
                    .setDescription('A ticket has been automatically closed due to no response')
                    .addFields([
                        { name: '👤 Ticket Owner', value: `${user.tag} (${user.id})`, inline: true },
                        { name: '🔒 Close Requested By', value: `${requestedBy.tag} (${requestedBy.id})`, inline: true },
                        { name: '📋 Type', value: ticketData.ticketType, inline: true },
                        { name: '📝 Reason', value: ticketData.closeRequest.reason, inline: false },
                        { name: '🆔 Ticket ID', value: ticketChannelId, inline: false },
                        { name: '🕐 Created At', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                        { name: '📨 Close Requested At', value: `<t:${Math.floor(ticketData.closeRequest.requestedAt / 1000)}:F>`, inline: true },
                        { name: '🤖 Auto-Closed At', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    ])
                    .setColor('#ff6600')
                    .setTimestamp()
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }));

                if (transcript && transcript.length > 0) {
                    const Buffer = require('buffer').Buffer;
                    const transcriptBuffer = Buffer.from(transcript, 'utf8');
                    
                    await logChannel.send({
                        embeds: [logEmbed],
                        files: [{
                            attachment: transcriptBuffer,
                            name: `ticket-${ticketChannelId}-transcript.txt`
                        }]
                    });
                } else {
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

            // Send final auto-close message
            const autoCloseEmbed = new EmbedBuilder()
                .setTitle('🤖 Ticket Auto-Closed')
                .setDescription('This ticket has been automatically closed due to no response from the ticket owner within 1 hour.\n\n*Channel will be deleted in 10 seconds...*\n\nSigned,\nCoaster Games Studio Support Team\nCoasterTickets')
                .setColor('#ff6600')
                .setTimestamp();

            await channel.send({
                embeds: [autoCloseEmbed]
            });

            // Remove from active tickets
            client.ticketManager.removeTicket(ticketChannelId);

            // Delete channel after delay
            setTimeout(async () => {
                try {
                    await channel.delete('Ticket auto-closed - no response');
                } catch (error) {
                    console.error('Error deleting auto-closed ticket channel:', error);
                }
            }, 10000);

            console.log(`Auto-closed ticket ${ticketChannelId} due to no response`);

        } catch (error) {
            console.error('Error in auto-close process:', error);
        }
    }
};
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Function to update ticket status
function updateTicketStatus(client, channelId, newStatus, userId) {
    const ticketData = client.ticketManager.getTicket(channelId);
    if (!ticketData) return false;

    const oldStatus = ticketData.status || 'unclaimed';
    
    // Don't update if status hasn't changed
    if (oldStatus === newStatus) return false;

    // Initialize status history if it doesn't exist
    if (!ticketData.statusHistory) {
        ticketData.statusHistory = [];
    }

    // Add status change to history
    ticketData.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: newStatus,
        changedBy: userId,
        changedAt: Date.now()
    });

    // Update current status
    ticketData.status = newStatus;
    
    // Save the updated ticket data
    client.ticketManager.updateTicket(channelId, ticketData);
    
    return true;
}

module.exports = {
    name: 'claim_ticket',
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const ticketChannelId = interaction.customId.split('_')[2];
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        // Check if user has support role
        if (!interaction.member.roles.cache.has(supportRoleId)) {
            return await interaction.editReply({
                content: '❌ You need the support role to claim tickets.'
            });
        }

        // Use the persistent ticket manager instead of activeTickets
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.editReply({
                content: '❌ Ticket data not found.'
            });
        }

        if (ticketData.claimed) {
            return await interaction.editReply({
                content: `❌ This ticket is already claimed by ${ticketData.claimedBy}.`
            });
        }

        // Update ticket data
        ticketData.claimed = true;
        ticketData.claimedBy = interaction.user.tag;
        ticketData.claimedById = interaction.user.id;
        ticketData.claimedAt = Date.now();

        // Update status to claimed and track status change
        updateTicketStatus(interaction.client, ticketChannelId, 'claimed', interaction.user.id);

        // Update channel name with status indicator
        const statusPrefix = '🟠';
        const currentChannelName = interaction.channel.name;
        let newChannelName;
        
        // Remove any existing status prefix
        const cleanChannelName = currentChannelName.replace(/^[🟡🟠🔴🟢⚫🔵]\s*/, '');
        newChannelName = `${statusPrefix} ${cleanChannelName}`;
        
        try {
            await interaction.channel.setName(newChannelName);
            console.log(`Channel name updated from "${currentChannelName}" to "${newChannelName}"`);
        } catch (error) {
            console.error('Error updating channel name:', error);
        }

        // Save the updated ticket data
        interaction.client.ticketManager.updateTicket(ticketChannelId, ticketData);

        // Update the welcome embed
        try {
            const welcomeMessage = await interaction.channel.messages.fetch(ticketData.welcomeMessageId);
            const originalEmbed = welcomeMessage.embeds[0];
            
            const updatedEmbed = new EmbedBuilder()
                .setTitle(originalEmbed.title)
                .setDescription(originalEmbed.description)
                .setColor('#FFA500') // Orange color for claimed status
                .setTimestamp() // Use current timestamp instead
                .setThumbnail(originalEmbed.thumbnail?.url)
                .setFooter(originalEmbed.footer)
                .setFields(
                    { name: '📋 Ticket Type', value: ticketData.ticketType, inline: true },
                    { name: '👤 Created by', value: `<@${ticketData.userId}>`, inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: `🟠 Claimed by ${interaction.user.tag}`, inline: true },
                    { name: '⏰ Claimed at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                );

            // Update buttons - disable claim button
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannelId}`)
                .setLabel(`Claimed by ${interaction.user.username}`)
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('✅')
                .setDisabled(true);

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannelId}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            await welcomeMessage.edit({
                embeds: [updatedEmbed],
                components: [buttonRow]
            });

            // Send claim message
            const claimEmbed = new EmbedBuilder()
                .setTitle('🔒 Ticket Claimed')
                .setDescription(`This ticket has been claimed by ${interaction.user}`)
                .addFields([
                    { name: '📊 Status Updated', value: '🟠 Claimed', inline: true },
                    { name: '⏰ Claimed at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                ])
                .setColor('#FFA500')
                .setTimestamp();

            await interaction.channel.send({ embeds: [claimEmbed] });

            // Log to log channel
            const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🔒 Ticket Claimed')
                    .setDescription('A ticket has been claimed')
                    .addFields([
                        { name: '🎫 Ticket', value: `${interaction.channel} (${ticketChannelId})`, inline: true },
                        { name: '👤 Claimed by', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                        { name: '📋 Type', value: ticketData.ticketType, inline: true },
                        { name: '📊 Status', value: '🟠 Claimed', inline: true }
                    ])
                    .setColor('#FFA500')
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

            console.log(`Ticket ${ticketChannelId} claimed by ${interaction.user.tag} (${interaction.user.id}) - Status updated to claimed`);

            await interaction.editReply({
                content: '✅ Ticket claimed successfully! Status updated to 🟠 Claimed'
            });

        } catch (error) {
            console.error('Error claiming ticket:', error);
            await interaction.editReply({
                content: '❌ Error claiming ticket. Please try again.'
            });
        }
    }
};
const { PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'ticket_select',
    async execute(interaction) {
        // Defer the reply to prevent timeout
        await interaction.deferReply({ ephemeral: true });

        const selectedValue = interaction.values[0];
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        const generalticketCategoryId = '1417274268487516381';
        const userreportticketCategoryId = '1417274325844754462';
        const birthdayticketCategoryId = '1417274369633161408';
        const devticketCategoryId = '1417274417947607121';
        const staffappCategoryId = '1444755920662958245';
        const guild = interaction.guild;
        const user = interaction.user;

        // Get the original ticket type name from stored data
        const storedTicketTypes = interaction.client.ticketTypes?.get(guild.id) || [];
        let ticketTypeName = selectedValue.replace(/_/g, ' ');
        
        // Find the original ticket type name (case-sensitive)
        const originalTicketType = storedTicketTypes.find(type => 
            type.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') === selectedValue
        );
        
        if (originalTicketType) {
            ticketTypeName = originalTicketType;
        }

        // Determine the appropriate category based on ticket type
        let ticketCategoryId;
        const lowerTicketType = ticketTypeName.toLowerCase();
        
        if (lowerTicketType.includes('report') || lowerTicketType.includes('user') || lowerTicketType.includes('abuse')) {
            ticketCategoryId = userreportticketCategoryId;
        } else if (lowerTicketType.includes('birthday') || lowerTicketType.includes('event') || lowerTicketType.includes('celebration')) {
            ticketCategoryId = birthdayticketCategoryId;
        } else if (lowerTicketType.includes('dev') || lowerTicketType.includes('development') || lowerTicketType.includes('bug') || lowerTicketType.includes('technical')) {
            ticketCategoryId = devticketCategoryId;
        } else if (lowerTicketType.includes('staff') || lowerTicketType.includes('app')) {
            ticketCategoryId = staffappCategoryId;
        } else {
            // Default to general ticket category
            ticketCategoryId = generalticketCategoryId;
        }

        // Create channel name: "type-username" with unclaimed status prefix
        const baseChannelName = `${selectedValue}-${user.username}`.toLowerCase()
            .replace(/[^a-z0-9_-]/g, '') // Remove invalid characters
            .substring(0, 95); // Leave room for status prefix (Discord limit is 100)
            
        const channelName = `🟡 ${baseChannelName}`; // Add unclaimed status prefix

        try {
            // Check if user already has a ticket using persistent storage
            const allTickets = interaction.client.ticketManager.getAllTickets();
            let existingChannel = null;
            
            for (const [channelId, ticketData] of allTickets.entries()) {
                if (ticketData.userId === user.id) {
                    const channel = guild.channels.cache.get(channelId);
                    if (channel) {
                        existingChannel = channel;
                        break;
                    } else {
                        // Channel doesn't exist anymore, clean up the data
                        interaction.client.ticketManager.removeTicket(channelId);
                    }
                }
            }

            if (existingChannel) {
                return await interaction.editReply({
                    content: `❌ You already have an open ticket: ${existingChannel}`
                });
            }

            // Get support role
            const supportRole = guild.roles.cache.get(supportRoleId);
            if (!supportRole) {
                return await interaction.editReply({
                    content: '❌ Support role not found. Please contact an administrator.'
                });
            }

            // Verify the category exists
            const ticketCategory = guild.channels.cache.get(ticketCategoryId);
            if (!ticketCategory || ticketCategory.type !== ChannelType.GuildCategory) {
                console.warn(`Ticket category ${ticketCategoryId} not found or is not a category. Creating channel without category.`);
            }

            // Create the ticket channel
            const ticketChannel = await guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                parent: ticketCategoryId, // Place in the appropriate category
                topic: `${ticketTypeName} ticket created by ${user.tag} (${user.id})`,
                permissionOverwrites: [
                    {
                        id: guild.roles.everyone.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks
                        ]
                    },
                    {
                        id: supportRoleId,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks,
                            PermissionFlagsBits.ManageMessages,
                            PermissionFlagsBits.ManageChannels
                        ]
                    },
                    {
                        id: interaction.client.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.ManageMessages,
                            PermissionFlagsBits.ManageChannels
                        ]
                    }
                ]
            });

            // Create welcome embed for the ticket
            const welcomeEmbed = new EmbedBuilder()
                .setTitle(`🎫 ${ticketTypeName} Ticket`)
                .setDescription(`Hello ${user}, welcome to your support ticket!\n\nPlease describe your issue in detail and a member of our support team will assist you shortly.`)
                .addFields([
                    { name: '📋 Ticket Type', value: ticketTypeName, inline: true },
                    { name: '👤 Created by', value: user.toString(), inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: '🟡 Unclaimed', inline: true },
                    { name: '📂 Category', value: ticketCategory ? ticketCategory.name : 'Unknown', inline: true }
                ])
                .setColor('#00ff00')
                .setTimestamp()
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setFooter({ 
                    text: `Ticket ID: ${ticketChannel.id}`,
                    iconURL: guild.iconURL({ dynamic: true })
                });

            // Create buttons
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannel.id}`)
                .setLabel('Claim Ticket')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('✋');

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannel.id}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            // Send welcome message to the ticket channel
            const welcomeMessage = await ticketChannel.send({
                content: `${user} | ${supportRole}`,
                embeds: [welcomeEmbed],
                components: [buttonRow]
            });

            // Log ticket creation
            console.log(`Ticket created: ${channelName} for user ${user.tag} (${user.id}) in category ${ticketCategory ? ticketCategory.name : 'Unknown'} (${ticketCategoryId})`);

            // Store ticket data using persistent storage with initial status
            const ticketData = {
                userId: user.id,
                username: user.username,
                userTag: user.tag,
                ticketType: ticketTypeName,
                categoryId: ticketCategoryId,
                categoryName: ticketCategory ? ticketCategory.name : 'Unknown',
                createdAt: Date.now(),
                claimed: false,
                claimedBy: null,
                claimedById: null,
                channelName: channelName,
                originalName: channelName,
                welcomeMessageId: welcomeMessage.id,
                closeRequest: null,
                autoCloseTimeout: null,
                status: 'unclaimed', // Initialize with unclaimed status
                statusHistory: [], // Track status changes
                renameHistory: [] // Initialize rename history
            };
            
            interaction.client.ticketManager.addTicket(ticketChannel.id, ticketData);

            // Log ticket creation to log channel
            const logChannel = guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🎫 Ticket Created')
                    .setDescription(`A new ticket has been created`)
                    .addFields([
                        { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                        { name: '📋 Type', value: ticketTypeName, inline: true },
                        { name: '📺 Channel', value: ticketChannel.toString(), inline: true },
                        { name: '📂 Category', value: ticketCategory ? ticketCategory.name : 'Unknown', inline: true },
                        { name: '🆔 Ticket ID', value: ticketChannel.id, inline: false },
                        { name: '🏷️ Status', value: '🟡 Unclaimed', inline: true }
                    ])
                    .setColor('#00ff00')
                    .setTimestamp()
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }));

                await logChannel.send({ embeds: [logEmbed] });
            }

            // Confirm ticket creation
            await interaction.editReply({
                content: `✅ Ticket created successfully in ${ticketCategory ? ticketCategory.name : 'default category'}! ${ticketChannel}`
            });

        } catch (error) {
            console.error('Error creating ticket:', error);
            
            let errorMessage = '❌ Failed to create ticket. ';
            
            if (error.code === 50013) {
                errorMessage += 'Missing permissions to create channels.';
            } else if (error.code === 50035) {
                errorMessage += 'Invalid channel configuration.';
            } else {
                errorMessage += 'Please try again or contact an administrator.';
            }
            
            await interaction.editReply({
                content: errorMessage
            });
        }
    }
};
# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project overview

This repository contains two related Node.js services:
- A Discord bot (entrypoint: `bot.js`) that manages a ticketing/support workflow for a Discord server using `discord.js` v14.
- A small Express-based HTTP API (`rankapi.js`) that integrates with Roblox via `noblox.js` to promote or set ranks in a Roblox group.

The bot persists ticket state to disk so tickets survive restarts and supports rich interaction handling (slash commands, buttons, select menus, and modals). The Roblox API is a separate long-running process that listens on its own port.

## Installation and runtime requirements

- Node.js and npm must be installed.
- Install dependencies from the repo root:
  - `npm install`
- Environment variables are required (typically via a local `.env` that is **not** committed to git):
  - `BOT_TOKEN` – Discord bot token used by `bot.js`.
  - `ROBLOX_COOKIE` – Roblox authentication cookie used by `rankapi.js`.
  - `RBX_WEBHOOK_KEY` – shared secret for HTTP endpoints in `rankapi.js`.
  - `ROBLOX_GROUP_ID` – numeric Roblox group ID used by `rankapi.js`.

## Common commands

From the repository root:

- Install dependencies (run this first):
  - `npm install`

- Run the Discord ticket bot:
  - `node bot.js`

- Run the Roblox rank API service (ensure Node is configured to support ES modules, or adjust the project configuration accordingly):
  - `node rankapi.js`

### Build, lint, and tests

- There are currently **no npm scripts** defined in `package.json` for build, lint, or tests, and there is no test runner configured in the codebase.
- Before asking Warp to run tests or lint, add appropriate tooling (for example, Jest for tests or ESLint for linting) and add scripts under the `"scripts"` section of `package.json`.

## High-level architecture

### Discord bot (`bot.js` and `commands/`, `handlers/`)

- **Entrypoint and client setup**
  - `bot.js` is the main entrypoint. It:
    - Loads environment variables via `dotenv`.
    - Creates a `discord.js` `Client` with intents for guilds, messages, message content, and members.
    - Loads slash commands from the `commands/` directory into `client.commands`.
    - Loads interaction handlers (buttons and select menus) from `handlers/buttons/` and `handlers/selectMenus/` into `client.handlers`.
    - Attaches a shared `TicketManager` instance as `client.ticketManager` (and `client.activeTickets` for backwards compatibility).

- **Ticket persistence and lifecycle (`TicketManager` in `bot.js`)**
  - `TicketManager` is defined in `bot.js` and is responsible for long-lived ticket state:
    - Persists tickets under `data/tickets.json` and ensures the `data/` directory exists.
    - On startup, loads previously active tickets and restores any pending auto-close timeouts.
    - Exposes methods to add, update, remove, and list tickets (`addTicket`, `updateTicket`, `removeTicket`, `getTicket`, `getAllTickets`).
    - Periodically autosaves tickets every 5 minutes via `startAutoSave()`.
  - Ticket records track fields used throughout the bot, such as:
    - Ticket identifiers, creator, ticket type, timestamps.
    - Status, status history, rename history (for ticket renames).
    - Claim information (who claimed, when, current status).
    - References to the welcome message and any auto-close timeouts.

- **Interaction routing**
  - `bot.js` defines a central `interactionHandlers` object and a unified `interactionCreate` listener:
    - Routes `ChatInputCommand` (slash commands) to the appropriate command object in `client.commands`.
    - Routes modal submissions to `client.modalHandler` or specific close-ticket handlers.
    - Routes string select menus and buttons to the appropriate handler in `client.handlers`, using `customId` patterns and `getButtonHandlerName`.
  - `handlers/modalHandler.js` encapsulates modal-specific logic, including:
    - Dynamic panel creation and sending.
    - Close-reason capture and confirmation workflow for ticket closure (using ephemeral confirmation embeds and buttons, plus temporary state in `client.tempCloseData`).

- **Ticket creation (`handlers/selectMenus/ticket_select.js`)**
  - This handler creates ticket channels when a user selects a ticket type from a select menu:
    - Maps the logical ticket type to a Discord category (general, user report, birthday, development, staff applications) using configured category IDs.
    - Enforces a "one open ticket per user" rule using persistent `TicketManager` state; cleans up stale entries if channels no longer exist.
    - Creates a ticket channel under the appropriate category with:
      - Permissions for the ticket creator, a support role, and the bot.
      - A channel name prefixed with a status indicator emoji (e.g., `🟡`).
    - Sends a welcome embed with ticket metadata and Claim/Close buttons.
    - Registers the ticket with `TicketManager.addTicket` and logs creation to a dedicated ticket log channel.

- **Ticket claiming and status changes (`commands/claim.js`, `handlers/buttons/claim_ticket.js`)**
  - Both the `/claim` slash command and the `claim_ticket` button handler:
    - Verify the caller has the configured support role.
    - Load ticket data from `TicketManager` and ensure the ticket exists and is unclaimed.
    - Update ticket fields (claimed flag, who claimed, timestamps).
    - Maintain a `status` field and `statusHistory` array to track transitions (e.g., `unclaimed` → `claimed`).
    - Update the ticket channel name to reflect status using emoji prefixes.
    - Update the original welcome embed (color, status text, claim time) and adjust the action buttons (disabling the claim button).
    - Send a "ticket claimed" embed in the ticket channel and a log embed in the log channel.

- **Ticket information and metadata (`commands/ticket-info.js`)**
  - Provides an overview of the current ticket when run in a ticket channel:
    - Shows creator, claimed-by, creation time, original/current channel names, rename history, current status, and a summarized status history.
    - Status is normalized into readable labels with emoji (e.g., `🟠 Claimed`, `🔴 Awaiting HR`).

- **Command registration and resync**
  - `bot.js` defines three related flows using the Discord REST API:
    - `registerSlashCommands()` – the normal path used on `ready` to register global and guild-specific commands.
    - `forceRefreshGuildCommands(guildId)` – utility to clear and re-register commands for a specific guild.
    - `fullCommandResync(message)` – admin-triggered via a `!resync` text command to completely clear and re-register commands (both global and for a problematic guild), with progress updates via message edits.

- **Graceful shutdown and error handling**
  - On `SIGINT`/`SIGTERM`, `gracefulShutdown` persists ticket data and then exits.
  - `client.on('error', ...)` logs client errors.

### Roblox rank API (`rankapi.js`)

- A separate Express application that listens on port `3001` and integrates with `noblox.js`:
  - Initializes a Roblox session via `noblox.setCookie(ROBLOX_COOKIE)`.
  - Defines JSON HTTP endpoints that require a shared `RBX_WEBHOOK_KEY`:
    - `POST /ranking-stick` – promotes a target user within the configured Roblox group using `noblox.promote`.
    - `POST /set-rank-3` – forcibly sets a user to rank `3` using `noblox.setRank`.
  - Logs both successful operations and blocked/failed attempts.

## How future Warp agents should work in this repo

- When modifying ticket behavior, prefer updating the shared `TicketManager` data structure and the centralized interaction handlers rather than duplicating persistence logic in individual commands.
- Any new ticket states, categories, or workflows should:
  - Update both the creation logic (`handlers/selectMenus/ticket_select.js` and/or other creation entrypoints) and the status display/summary logic (e.g., `ticket-info` and logging embeds).
  - Ensure `TicketManager` saves/restores any new fields you add to ticket records so they survive restarts.
- If you introduce build steps, linting, or tests, add explicit `"scripts"` entries to `package.json` so Warp can invoke them reliably from the repo root.

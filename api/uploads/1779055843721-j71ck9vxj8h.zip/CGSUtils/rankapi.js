import express from "express";
import noblox from "noblox.js";
import 'dotenv/config';

const app = express();
app.use(express.json());

async function init() {
    const cookie = process.env.ROBLOX_COOKIE;
    await noblox.setCookie(cookie);
    console.log("Logged into Roblox!");
}

init();

const API_KEY = process.env.RBX_WEBHOOK_KEY; // set this in .env
const ROBLOX_GROUP_ID = Number(process.env.ROBLOX_GROUP_ID);

// --- Roblox Stick Trigger Endpoint ---
app.post("/ranking-stick", async (req, res) => {
    const { targetUserId, key } = req.body;

    if (key !== API_KEY) { 
        console.log("Blocked unauthorized request.");
        return res.status(403).send("Forbidden");
    }

    if (!targetUserId) {
        return res.status(400).send("Missing targetUserId");
    }

    try {
        const newRole = await noblox.promote(ROBLOX_GROUP_ID, targetUserId);

        console.log(`[Ranking Stick] Promoted User ${targetUserId} → Rank ${newRole.name}`);
        return res.send("Success");
    } catch (err) {
        console.error("Ranking stick promotion failed:", err);
        return res.status(500).send("Error");
    }
});

// --- Force Rank 3 Endpoint ---
app.post("/set-rank-3", async (req, res) => {
    const { targetUserId, key } = req.body;

    if (key !== API_KEY) {
        console.log("Blocked unauthorized request.");
        return res.status(403).send("Forbidden");
    }   

    if (!targetUserId) {
        return res.status(400).send("Missing targetUserId");
    }

    try {
        await noblox.setRank(ROBLOX_GROUP_ID, targetUserId, 3);

        console.log(`[Rank API] Set User ${targetUserId} → Rank 3`);
        return res.send("Ranked to 3");
    } catch (err) {
        console.error("Rank 3 assignment failed:", err);
        return res.status(500).send("Error setting rank");
    }
});


app.listen(3001, () => console.log("Roblox API listener active on port 3001"));

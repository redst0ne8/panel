const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Store session data for auto-deletion
const sessionData = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('hostsession')
        .setDescription('Host a training session')
        .addStringOption(option =>
            option.setName('time')
                .setDescription('Starting time (e.g., "in 10 minutes", "in 1 hour", "in 30 mins")')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Optional description for the session')
                .setRequired(false)),
    
    async execute(interaction) {
        // Check if user has the required role
        const requiredRoleId = '1417278720426770572';
        const targetChannelId = '1396953078967828584';
        const pingRoleId = '1396881413411700917';
        const gameLink = 'https://rblx.games/89039239684856';
        
        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return await interaction.reply({
                content: 'You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const timeInput = interaction.options.getString('time');
        
        // Parse natural language time input
        const startTime = parseTimeInput(timeInput);
        if (!startTime) {
            return await interaction.reply({
                content: 'Invalid time format. Please use formats like "in 10 minutes", "in 1 hour", "in 30 mins", etc.',
                ephemeral: true
            });
        }
        
        // Create Discord timestamps (absolute and relative)
        const unixTimestamp = Math.floor(startTime.getTime() / 1000);
        const absoluteTimestamp = `<t:${unixTimestamp}:F>`;
        const relativeTimestamp = `<t:${unixTimestamp}:R>`;
        const combinedTimestamp = `${absoluteTimestamp}\n${relativeTimestamp}`;
        const description = interaction.options.getString('description') || 'No description provided.';

        // Generate unique session ID
        const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // Create embed
        
        const embed = new EmbedBuilder()
            .setTitle('🎮 Training Session Starting Soon!')
            .setColor('#00ff00')
            .addFields(
                { name: '⏰ Starting Time', value: combinedTimestamp, inline: true },
                { name: '⏱️ Duration', value: '30 minutes - 1 hour', inline: true },
                { name: '📋 Description', value: description, inline: false}
            )
            .setFooter(
                { text: 'CoasterSessions', iconURL: 'https://cdn.discordapp.com/attachments/1396957229902598214/1415856056008970374/CoasterTicketsImg.JPG?ex=68c95775&is=68c805f5&hm=fee85b9e46d8517d14800d6162eab17dc460f4fea46bd4c9e0172f92f465c6c6&'}
            )

        // Create buttons
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Join Game')
                    .setStyle(ButtonStyle.Link)
                    .setURL(gameLink)
                    .setEmoji('🎮')
            );

        try {
            // Get target channel
            const targetChannel = await interaction.client.channels.fetch(targetChannelId);
            
            // Send message to target channel with role ping
            const message = await targetChannel.send({
                content: `<@&${pingRoleId}>`,
                embeds: [embed],
                components: [row]
            });

            // Store session data for auto-deletion
            sessionData.set(sessionId, {
                messageId: message.id,
                channelId: targetChannelId,
                client: interaction.client
            });

            // Schedule auto-deletion after 1 hour
            setTimeout(async () => {
                await autoDeleteMessage(sessionId);
            }, 3600000); // 1 hour = 3,600,000 milliseconds

            await interaction.reply({
                content: `Session successfully posted to <#${targetChannelId}>! The message will be automatically deleted in 1 hour.`,
                ephemeral: true
            });

        } catch (error) {
            console.error('Error sending session message:', error);
            await interaction.reply({
                content: 'There was an error posting the session. Please make sure I have permission to send messages in the target channel.',
                ephemeral: true
            });
        }
    },
};

// Function to parse natural language time input
function parseTimeInput(input) {
    const now = new Date();
    const lowerInput = input.toLowerCase().trim();
    
    // Remove common words and normalize
    const cleanInput = lowerInput.replace(/^in\s+/, '').replace(/\s+from\s+now$/, '');
    
    // Regex patterns for different time formats
    const patterns = [
        // "5 minutes", "10 mins", "1 minute"
        { regex: /^(\d+)\s*(minute|minutes|min|mins)$/, multiplier: 60000 },
        // "2 hours", "1 hour", "3 hrs"
        { regex: /^(\d+)\s*(hour|hours|hr|hrs)$/, multiplier: 3600000 },
        // "1 hour 30 minutes", "2 hrs 15 mins"
        { regex: /^(\d+)\s*(hour|hours|hr|hrs)\s+(\d+)\s*(minute|minutes|min|mins)$/, 
          handler: (matches) => (parseInt(matches[1]) * 3600000) + (parseInt(matches[3]) * 60000) },
        // "30 seconds", "45 secs"
        { regex: /^(\d+)\s*(second|seconds|sec|secs)$/, multiplier: 1000 },
    ];
    
    for (const pattern of patterns) {
        const match = cleanInput.match(pattern.regex);
        if (match) {
            let milliseconds;
            if (pattern.handler) {
                milliseconds = pattern.handler(match);
            } else {
                milliseconds = parseInt(match[1]) * pattern.multiplier;
            }
            
            // Validate reasonable time ranges (1 second to 24 hours)
            if (milliseconds >= 1000 && milliseconds <= 86400000) {
                return new Date(now.getTime() + milliseconds);
            }
        }
    }
    
    return null;
}

// Function to auto-delete session message
async function autoDeleteMessage(sessionId) {
    try {
        const session = sessionData.get(sessionId);
        
        if (!session) return;
        
        const { messageId, channelId, client } = session;
        
        const channel = await client.channels.fetch(channelId);
        const message = await channel.messages.fetch(messageId);
        
        if (message) {
            await message.delete();
            console.log(`Auto-deleted session message ${messageId} after 1 hour`);
        }
        
        // Clean up session data
        sessionData.delete(sessionId);
        
    } catch (error) {
        console.error(`Error auto-deleting session message:`, error);
        // Clean up data even if deletion failed
        sessionData.delete(sessionId);
    }
}
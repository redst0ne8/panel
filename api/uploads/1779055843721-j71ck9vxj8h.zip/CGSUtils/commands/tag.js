const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Load tag configuration
function loadTagConfig() {
    try {
        const configPath = path.join(__dirname, '..', 'config', 'tags.json');
        if (!fs.existsSync(configPath)) {
            console.error('Tag configuration file not found at:', configPath);
            return null;
        }
        const configData = fs.readFileSync(configPath, 'utf8');
        return JSON.parse(configData);
    } catch (error) {
        console.error('Error loading tag configuration:', error);
        return null;
    }
}

// Function to update ticket status
function updateTicketStatus(client, channelId, newStatus, userId) {
    const ticketData = client.ticketManager.getTicket(channelId);
    if (!ticketData) return false;

    const oldStatus = ticketData.status || 'unclaimed';
    
    // Don't update if status hasn't changed
    if (oldStatus === newStatus) return false;

    // Initialize status history if it doesn't exist
    if (!ticketData.statusHistory) {
        ticketData.statusHistory = [];
    }

    // Add status change to history
    ticketData.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: newStatus,
        changedBy: userId,
        changedAt: Date.now()
    });

    // Update current status
    ticketData.status = newStatus;
    
    // Save the updated ticket data
    client.ticketManager.updateTicket(channelId, ticketData);
    
    return true;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tag')
        .setDescription('Send a predefined tag message')
        .addStringOption(option =>
            option.setName('tag')
                .setDescription('Select a tag to send')
                .setRequired(true)
                .addChoices(
                    { name: 'Opening', value: 'opening' },
                    { name: 'Closing', value: 'closing' },
                    { name: 'Escalate', value: 'escalate' },
                    { name: 'Inactive', value: 'inactive' },
                    { name: 'Evidence', value: 'evidence' },
                    { name: 'Birthday', value: 'birthday' },
                    { name: 'Development', value: 'development' }
                )),
    
    async execute(interaction) {
        try {
            const supportRoleId = '1400261853220962486';
            
            // Check if user has support role - REQUIRED FOR ALL USERS
            if (!interaction.member.roles.cache.has(supportRoleId)) {
                return await interaction.reply({
                    content: '❌ You need the support role to use tag commands.',
                    ephemeral: true
                });
            }

            const selectedTag = interaction.options.getString('tag');
            const tagConfig = loadTagConfig();
            
            if (!tagConfig) {
                return await interaction.reply({
                    content: '❌ Error loading tag configuration. Please contact an administrator.',
                    ephemeral: true
                });
            }
            
            const tagData = tagConfig.tags[selectedTag];
            if (!tagData) {
                return await interaction.reply({
                    content: `❌ Tag "${selectedTag}" not found in configuration.`,
                    ephemeral: true
                });
            }
            
            // Check if this is a ticket channel
            const ticketData = interaction.client.ticketManager.getTicket(interaction.channel.id);
            
            // Update ticket status based on tag used
            let statusUpdated = false;
            let statusPrefix = '';
            if (ticketData) {
                let newStatus = null;
                
                switch (selectedTag) {
                    case 'escalate':
                        newStatus = 'escalated';
                        statusPrefix = '🔴'; // Red circle
                        break;
                    case 'closing':
                        newStatus = 'resolved';
                        statusPrefix = '🟢'; // Green circle
                        break;
                    case 'inactive':
                        newStatus = 'inactive';
                        statusPrefix = '⚫'; // Black circle
                        break;
                    case 'development':
                        newStatus = 'development';
                        statusPrefix = '🔵'; // Blue circle
                        break;
                    // 'opening' and 'evidence' don't change status
                }
                
                if (newStatus) {
                    statusUpdated = updateTicketStatus(
                        interaction.client, 
                        interaction.channel.id, 
                        newStatus, 
                        interaction.user.id
                    );
                    
                    // Update channel name with status indicator
                    if (statusUpdated && statusPrefix) {
                        try {
                            const currentChannelName = interaction.channel.name;
                            // Remove any existing status prefix (including all possible status emojis)
                            const cleanChannelName = currentChannelName.replace(/^[🟡🟠🔴🟢⚫🔵]\s*/, '');
                            const newChannelName = `${statusPrefix} ${cleanChannelName}`;
                            
                            await interaction.channel.setName(newChannelName);
                            console.log(`Channel name updated from "${currentChannelName}" to "${newChannelName}" via tag: ${selectedTag}`);
                        } catch (error) {
                            console.error('Error updating channel name:', error);
                        }
                    }
                }
            }
            
            // Create embed
            const embed = new EmbedBuilder()
                .setTitle(tagData.title)
                .setDescription(tagData.description)
                .setColor(0x0099FF) // Blue color
                .setAuthor({
                    name: interaction.user.displayName || interaction.user.username,
                    iconURL: interaction.user.displayAvatarURL()
                })
                .setFooter({
                    text: 'CoasterTickets Support',
                    iconURL: interaction.client.user.displayAvatarURL()
                })
                .setTimestamp();
            
            // Add status update notification if applicable
            if (statusUpdated && ticketData) {
                const statusMap = {
                    'escalated': '🔴 Awaiting HR',
                    'resolved': '🟢 Resolved',
                    'inactive': '⚫ Inactive',
                    'development': '🔵 Awaiting Developer'
                };
                
                const statusDisplay = statusMap[ticketData.status];
                if (statusDisplay) {
                    embed.addFields({
                        name: '📊 Status Updated',
                        value: `Ticket status changed to: ${statusDisplay}`,
                        inline: false
                    });
                }
            }
            
            // Send the tag embed
            await interaction.reply({
                embeds: [embed]
            });
            
            // Log status change if it occurred
            if (statusUpdated) {
                console.log(`Ticket ${interaction.channel.id} status updated to ${ticketData.status} by ${interaction.user.tag} using tag: ${selectedTag}`);
                
                // Optional: Send log to ticket log channel
                const ticketLogChannelId = '1333307663421014016';
                const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
                if (logChannel) {
                    const statusMap = {
                        'escalated': '🔴 Awaiting HR',
                        'resolved': '🟢 Resolved',
                        'inactive': '⚫ Inactive',
                        'development': '🔵 Awaiting Developer'
                    };
                    
                    const logEmbed = new EmbedBuilder()
                        .setTitle('📊 Ticket Status Updated')
                        .setDescription(`Ticket status changed via tag usage`)
                        .addFields([
                            { name: '📺 Channel', value: interaction.channel.toString(), inline: true },
                            { name: '👤 Updated by', value: interaction.user.toString(), inline: true },
                            { name: '🏷️ Tag Used', value: selectedTag, inline: true },
                            { name: '📊 New Status', value: statusMap[ticketData.status] || ticketData.status, inline: false }
                        ])
                        .setColor('#FFA500')
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
            
        } catch (error) {
            console.error('Error executing tag command:', error);
            await interaction.reply({
                content: '❌ An error occurred while sending the tag.',
                ephemeral: true
            });
        }
    }
};
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const schedule = require('node-schedule');

// Store scheduled jobs
const scheduledJobs = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoschedule')
        .setDescription('Manage automatic training session announcements')
        .addSubcommand(subcommand =>
            subcommand
                .setName('start')
                .setDescription('Start automatic training session announcements'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stop')
                .setDescription('Stop automatic training session announcements'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('status')
                .setDescription('Check the status of scheduled sessions')),
    
    async execute(interaction) {
        const requiredRoleId = '1417278720426770572';
        
        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return await interaction.reply({
                content: 'You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'start') {
            await handleStart(interaction);
        } else if (subcommand === 'stop') {
            await handleStop(interaction);
        } else if (subcommand === 'status') {
            await handleStatus(interaction);
        }
    },
};

async function handleStart(interaction) {
    const guildId = interaction.guild.id;
    
    if (scheduledJobs.has(guildId)) {
        return await interaction.reply({
            content: '⚠️ Auto-scheduling is already running! Use `/autoschedule stop` to stop it first.',
            ephemeral: true
        });
    }

    // Training times in EST (these are the actual session times)
    // We'll announce 20 minutes before each
    const trainingTimes = [
        { hour: 11, minute: 0 },  // 11:00 EST
        { hour: 13, minute: 0 },  // 13:00 EST
        { hour: 15, minute: 0 },  // 15:00 EST
        { hour: 17, minute: 0 },  // 17:00 EST
        { hour: 19, minute: 0 },  // 19:00 EST
        { hour: 21, minute: 0 }   // 21:00 EST
    ];

    const jobs = [];

    for (const time of trainingTimes) {
        // Calculate announcement time (20 minutes before)
        let announceHour = time.hour;
        let announceMinute = time.minute - 20;
        
        if (announceMinute < 0) {
            announceMinute += 60;
            announceHour -= 1;
        }

        // Schedule job for EST timezone
        // Cron format: minute hour * * * (runs daily)
        const cronExpression = `${announceMinute} ${announceHour} * * *`;
        
        const job = schedule.scheduleJob(
            { hour: announceHour, minute: announceMinute, tz: 'America/New_York' },
            async () => {
                await sendTrainingAnnouncement(interaction.client, interaction.guild.id, time);
            }
        );

        jobs.push({
            time: `${String(time.hour).padStart(2, '0')}:${String(time.minute).padStart(2, '0')} EST`,
            announceTime: `${String(announceHour).padStart(2, '0')}:${String(announceMinute).padStart(2, '0')} EST`,
            job: job
        });
    }

    scheduledJobs.set(guildId, jobs);

    const scheduleList = jobs.map(j => `• Session at **${j.time}** → Announced at **${j.announceTime}**`).join('\n');

    await interaction.reply({
        content: `✅ **Auto-scheduling enabled!**\n\nTraining sessions will be announced 20 minutes before:\n${scheduleList}\n\n*All times are in EST timezone.*`,
        ephemeral: true
    });
}

async function handleStop(interaction) {
    const guildId = interaction.guild.id;
    
    if (!scheduledJobs.has(guildId)) {
        return await interaction.reply({
            content: '⚠️ Auto-scheduling is not currently running.',
            ephemeral: true
        });
    }

    const jobs = scheduledJobs.get(guildId);
    
    // Cancel all scheduled jobs
    for (const jobInfo of jobs) {
        jobInfo.job.cancel();
    }
    
    scheduledJobs.delete(guildId);

    await interaction.reply({
        content: '✅ Auto-scheduling has been stopped. All scheduled training announcements have been cancelled.',
        ephemeral: true
    });
}

async function handleStatus(interaction) {
    const guildId = interaction.guild.id;
    
    if (!scheduledJobs.has(guildId)) {
        return await interaction.reply({
            content: '📊 **Status:** Auto-scheduling is currently **disabled**.\n\nUse `/autoschedule start` to enable it.',
            ephemeral: true
        });
    }

    const jobs = scheduledJobs.get(guildId);
    const scheduleList = jobs.map(j => `• Session at **${j.time}** → Announced at **${j.announceTime}**`).join('\n');

    await interaction.reply({
        content: `📊 **Status:** Auto-scheduling is currently **enabled**.\n\n**Scheduled announcements:**\n${scheduleList}\n\n*All times are in EST timezone.*`,
        ephemeral: true
    });
}

async function sendTrainingAnnouncement(client, guildId, sessionTime) {
    const targetChannelId = '1396953078967828584';
    const pingRoleId = '1396881413411700917';
    const gameLink = 'https://rblx.games/89039239684856';

    try {
        // Calculate the session start time (20 minutes from now)
        const now = new Date();
        const sessionStart = new Date(now.getTime() + (20 * 60 * 1000));
        const unixTimestamp = Math.floor(sessionStart.getTime() / 1000);
        
        const absoluteTimestamp = `<t:${unixTimestamp}:F>`;
        const relativeTimestamp = `<t:${unixTimestamp}:R>`;
        const combinedTimestamp = `${absoluteTimestamp}\n${relativeTimestamp}`;

        const embed = new EmbedBuilder()
            .setTitle('🎮 Training Session Starting Soon!')
            .setColor('#00ff00')
            .addFields(
                { name: '⏰ Starting Time', value: combinedTimestamp, inline: true },
                { name: '⏱️ Duration', value: '30 minutes - 1 hour', inline: true },
                { name: '📋 Description', value: ':star:All ranks are welcome!\n:star:Please remember to follow all rules and guidelines.\n:star:Hope to see you there!', inline: false }
            )
            .setFooter({
                text: 'CoasterSessions',
                iconURL: 'https://cdn.discordapp.com/attachments/1396957229902598214/1415856056008970374/CoasterTicketsImg.JPG?ex=68c95775&is=68c805f5&hm=fee85b9e46d8517d14800d6162eab17dc460f4fea46bd4c9e0172f92f465c6c6&'
            });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Join Game')
                    .setStyle(ButtonStyle.Link)
                    .setURL(gameLink)
                    .setEmoji('🎮')
            );

        const targetChannel = await client.channels.fetch(targetChannelId);
        
        const message = await targetChannel.send({
            content: `<@&${pingRoleId}>`,
            embeds: [embed],
            components: [row]
        });

        // Schedule auto-deletion after 1 hour
        setTimeout(async () => {
            try {
                await message.delete();
                console.log(`Auto-deleted scheduled session message ${message.id}`);
            } catch (error) {
                console.error('Error auto-deleting scheduled message:', error);
            }
        }, 3600000); // 1 hour

        console.log(`Sent scheduled training announcement for ${sessionTime.hour}:${String(sessionTime.minute).padStart(2, '0')} EST session`);

    } catch (error) {
        console.error('Error sending scheduled training announcement:', error);
    }
}
const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sendpanel')
        .setDescription('Send your created embed panel with ticket system to a specific channel')
        .addStringOption(option =>
            option.setName('channel_id')
                .setDescription('The ID of the channel to send the embed to')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    
    async execute(interaction) {
        const channelId = interaction.options.getString('channel_id');
        
        // Get stored embed data
        const embed = interaction.client.tempEmbedData?.get(interaction.user.id);
        
        if (!embed) {
            return await interaction.reply({ 
                content: '❌ No embed data found. Please create an embed first using `/makepanel`.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }

        // Validate channel first
        try {
            const channel = await interaction.client.channels.fetch(channelId);
            
            if (!channel) {
                return await interaction.reply({ 
                    content: '❌ Channel not found. Please check the channel ID.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }

            if (!channel.isTextBased()) {
                return await interaction.reply({ 
                    content: '❌ The specified channel is not a text channel.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }

            const permissions = channel.permissionsFor(interaction.client.user);
            if (!permissions || !permissions.has(PermissionFlagsBits.SendMessages)) {
                return await interaction.reply({ 
                    content: '❌ I don\'t have permission to send messages in that channel.', 
                    flags: 64 // MessageFlags.Ephemeral
                });
            }
        } catch (error) {
            console.error('Error validating channel:', error);
            return await interaction.reply({ 
                content: '❌ Failed to validate channel. Please check the channel ID and try again.', 
                flags: 64 // MessageFlags.Ephemeral
            });
        }

        // Define the 4 predefined ticket types
        const ticketTypes = [
            'General Support/Help',
            'User Reports', 
            'Development/Suggestions',
            'Birthdays',
            'Staff Application'
        ];

        try {
            // Get the channel
            const channel = await interaction.client.channels.fetch(channelId);
            
            // Create the dropdown component with predefined options
            const ticketDropdown = this.createTicketDropdown(ticketTypes);
            
            // Send the embed with the ticket dropdown
            await channel.send({ 
                embeds: [embed],
                components: [ticketDropdown]
            });

            // Clean up temporary data
            interaction.client.tempEmbedData.delete(interaction.user.id);

            // Store ticket types for later use (optional - for reference)
            if (!interaction.client.ticketTypes) {
                interaction.client.ticketTypes = new Map();
            }
            interaction.client.ticketTypes.set(channel.guild.id, ticketTypes);

            // Confirm success
            const ticketTypesList = ticketTypes.map(type => `• ${type}`).join('\n');
            await interaction.reply({
                content: `✅ Ticket panel successfully sent to <#${channelId}>!\n\n**Ticket Types:**\n${ticketTypesList}`,
                flags: 64
            });

        } catch (error) {
            console.error('Error sending ticket panel:', error);
            
            // Clean up temporary data on error
            if (interaction.client.tempEmbedData) {
                interaction.client.tempEmbedData.delete(interaction.user.id);
            }
            
            let errorMessage = '❌ Failed to send ticket panel. ';
            
            if (error.code === 10003) {
                errorMessage += 'Channel not found. Please check the channel ID.';
            } else if (error.code === 50013) {
                errorMessage += 'Missing permissions to send messages in that channel.';
            } else if (error.code === 50001) {
                errorMessage += 'Missing access to that channel.';
            } else {
                errorMessage += 'Please check the channel ID and try again.';
            }
            
            await interaction.reply({
                content: errorMessage,
                flags: 64
            });
        }
    },

    // Helper function to create ticket dropdown with predefined options
    createTicketDropdown(ticketTypes) {
        const options = [
            {
                label: 'General Support/Help',
                description: 'Open a ticket for General Help.',
                value: 'general_support_help',
                emoji: '🎫'
            },
            {
                label: 'User Reports',
                description: 'Report a user.',
                value: 'user_reports',
                emoji: '🎫'
            },
            {
                label: 'Staff Applications',
                description: 'Get support for the automated application system.',
                value: 'staffapp',
                emoji: '🎫'
            },
            {
                label: 'Development/Suggestions',
                description: 'Suggest things to development.',
                value: 'development_suggestions',
                emoji: '🎫'
            },
            {
                label: 'Birthdays',
                description: 'Request the birthday role.',
                value: 'birthdays',
                emoji: '🎫'
            }
        ];

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('ticket_select')
            .setPlaceholder('Select a ticket type to create...')
            .addOptions(options);

        return new ActionRowBuilder().addComponents(selectMenu);
    }
};
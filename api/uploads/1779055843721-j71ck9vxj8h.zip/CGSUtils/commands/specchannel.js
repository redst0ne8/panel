const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('specchannel')
        .setDescription('Create a special channel with custom permissions')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Name of the channel to create')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to grant view permissions to')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to grant view permissions to')
                .setRequired(false)),

    async execute(interaction) {
        const REQUIRED_ROLE_ID = '1396877857220988978';
        
        // Check if user has the required role
        const member = interaction.guild.members.cache.get(interaction.user.id);
        const hasRequiredRole = member.roles.cache.has(REQUIRED_ROLE_ID);
        
        if (!hasRequiredRole) {
            return await interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const channelName = interaction.options.getString('name');
        const targetUser = interaction.options.getUser('user');
        const targetRole = interaction.options.getRole('role');

        // Validate that at least one target (user or role) is provided
        if (!targetUser && !targetRole) {
            return await interaction.reply({
                content: '❌ You must specify either a user or role to grant permissions to.',
                ephemeral: true
            });
        }

        try {
            // Create permission overwrites array
            const permissionOverwrites = [
                {
                    id: interaction.guild.roles.everyone,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                }
            ];

            // Add user permissions if specified
            if (targetUser) {
                permissionOverwrites.push({
                    id: targetUser.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                });
            }

            // Add role permissions if specified
            if (targetRole) {
                permissionOverwrites.push({
                    id: targetRole.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                });
            }

            // Create the channel
            const channel = await interaction.guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                parent: null, // No category
                permissionOverwrites: permissionOverwrites
            });

            // Build response message
            let responseMessage = `✅ Successfully created channel ${channel}!\n\n**Permissions granted to:**\n`;
            
            // Always include the command executor
            responseMessage += `👤 ${interaction.user} (creator)\n`;
            
            if (targetUser) {
                responseMessage += `👤 ${targetUser}\n`;
            }
            
            if (targetRole) {
                responseMessage += `🎭 ${targetRole}\n`;
            }

            await interaction.reply({
                content: responseMessage,
                ephemeral: false
            });

            // Send notification ping in the new channel
            const pingTargets = [`<@${interaction.user.id}>`]; // Always ping the creator
            
            if (targetUser) {
                pingTargets.push(`<@${targetUser.id}>`);
            }
            
            if (targetRole) {
                pingTargets.push(`<@&${targetRole.id}>`);
            }

            // Send the ping message to the new channel
            await channel.send({
                content: `📢 Welcome to your new channel! ${pingTargets.join(' ')}`
            });

        } catch (error) {
            console.error('Error creating special channel:', error);
            
            await interaction.reply({
                content: '❌ Failed to create the channel. Please check my permissions and try again.',
                ephemeral: true
            });
        }
    },
};
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Function to update ticket status
function updateTicketStatus(client, channelId, newStatus, userId) {
    const ticketData = client.ticketManager.getTicket(channelId);
    if (!ticketData) return false;

    const oldStatus = ticketData.status || 'unclaimed';
    
    // Don't update if status hasn't changed
    if (oldStatus === newStatus) return false;

    // Initialize status history if it doesn't exist
    if (!ticketData.statusHistory) {
        ticketData.statusHistory = [];
    }

    // Add status change to history
    ticketData.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: newStatus,
        changedBy: userId,
        changedAt: Date.now()
    });

    // Update current status
    ticketData.status = newStatus;
    
    return ticketData; // Return updated data instead of saving here
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('claim')
        .setDescription('Claim the current ticket')
        .setDefaultMemberPermissions(0), // Restrict by default, will check role in execute
    
    // Guild-specific registration for problematic server
    guildSpecific: true,
    targetGuild: '1396705648208646235',

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const ticketChannelId = interaction.channel.id;
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        // Check if user has support role
        if (!interaction.member.roles.cache.has(supportRoleId)) {
            return await interaction.editReply({
                content: '❌ You need the support role to claim tickets.'
            });
        }

        // Check if this is actually a ticket channel
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.editReply({
                content: '❌ This command can only be used in ticket channels.'
            });
        }

        if (ticketData.claimed) {
            return await interaction.editReply({
                content: `❌ This ticket is already claimed by ${ticketData.claimedBy}.`
            });
        }

        try {
            // Update all ticket data in one operation to ensure consistency
            const claimTime = Date.now();
            
            // Update ticket claim data
            ticketData.claimed = true;
            ticketData.claimedBy = interaction.user.tag;
            ticketData.claimedById = interaction.user.id;
            ticketData.claimedAt = claimTime;

            // Update status and get updated ticket data
            const updatedTicketData = updateTicketStatus(interaction.client, ticketChannelId, 'claimed', interaction.user.id);
            if (!updatedTicketData) {
                throw new Error('Failed to update ticket status');
            }

            // Save all changes at once
            interaction.client.ticketManager.updateTicket(ticketChannelId, updatedTicketData);

            // Update channel name with status indicator
            const statusPrefix = '🟠';
            const currentChannelName = interaction.channel.name;
            let newChannelName;
            
            // Remove any existing status prefix
            const cleanChannelName = currentChannelName.replace(/^[🟡🟠🔴🟢⚫🔵]\s*/, '');
            newChannelName = `${statusPrefix} ${cleanChannelName}`;
            
            try {
                await interaction.channel.setName(newChannelName);
                console.log(`Channel name updated from "${currentChannelName}" to "${newChannelName}"`);
            } catch (error) {
                console.error('Error updating channel name:', error);
                // Don't fail the entire operation if channel name update fails
            }

            // Update the welcome embed
            const welcomeMessage = await interaction.channel.messages.fetch(updatedTicketData.welcomeMessageId);
            const originalEmbed = welcomeMessage.embeds[0];
            
            const updatedEmbed = new EmbedBuilder()
                .setTitle(originalEmbed.title)
                .setDescription(originalEmbed.description)
                .setColor('#FFA500') // Orange color for claimed status
                .setTimestamp() // Use current timestamp instead
                .setThumbnail(originalEmbed.thumbnail?.url)
                .setFooter(originalEmbed.footer)
                .setFields(
                    { name: '📋 Ticket Type', value: updatedTicketData.ticketType, inline: true },
                    { name: '👤 Created by', value: `<@${updatedTicketData.userId}>`, inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(updatedTicketData.createdAt / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: `🟠 Claimed by ${interaction.user.tag}`, inline: true },
                    { name: '⏰ Claimed at', value: `<t:${Math.floor(claimTime / 1000)}:F>`, inline: true }
                );

            // Update buttons - disable claim button
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannelId}`)
                .setLabel(`Claimed by ${interaction.user.username}`)
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('✅')
                .setDisabled(true);

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannelId}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            await welcomeMessage.edit({
                embeds: [updatedEmbed],
                components: [buttonRow]
            });

            // Send claim message
            const claimEmbed = new EmbedBuilder()
                .setTitle('🔒 Ticket Claimed')
                .setDescription(`This ticket has been claimed by ${interaction.user}`)
                .addFields([
                    { name: '📊 Status Updated', value: '🟠 Claimed', inline: true },
                    { name: '⏰ Claimed at', value: `<t:${Math.floor(claimTime / 1000)}:F>`, inline: true }
                ])
                .setColor('#FFA500')
                .setTimestamp();

            await interaction.channel.send({ embeds: [claimEmbed] });

            // Log to log channel
            const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🔒 Ticket Claimed')
                    .setDescription('A ticket has been claimed')
                    .addFields([
                        { name: '🎫 Ticket', value: `${interaction.channel} (${ticketChannelId})`, inline: true },
                        { name: '👤 Claimed by', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                        { name: '📋 Type', value: updatedTicketData.ticketType, inline: true },
                        { name: '📊 Status', value: '🟠 Claimed', inline: true }
                    ])
                    .setColor('#FFA500')
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

            console.log(`Ticket ${ticketChannelId} claimed by ${interaction.user.tag} (${interaction.user.id}) - Status updated to claimed`);

            await interaction.editReply({
                content: '✅ Ticket claimed successfully! Status updated to 🟠 Claimed'
            });

        } catch (error) {
            console.error('Error claiming ticket:', error);
            await interaction.editReply({
                content: '❌ Error claiming ticket. Please try again.'
            });
        }
    }
};
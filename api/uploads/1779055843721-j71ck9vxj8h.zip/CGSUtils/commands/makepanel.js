const { SlashCommandBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('makepanel')
        .setDescription('Create a custom embed panel with title, description, author, and images')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    
    async execute(interaction) {
        // Create modal for embed configuration
        const modal = new ModalBuilder()
            .setCustomId('makepanel_modal')
            .setTitle('Create Embed Panel');

        // Create text inputs for embed properties
        const titleInput = new TextInputBuilder()
            .setCustomId('embed_title')
            .setLabel('Embed Title')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(256)
            .setRequired(false)
            .setPlaceholder('Enter the embed title...');

        const descriptionInput = new TextInputBuilder()
            .setCustomId('embed_description')
            .setLabel('Embed Description')
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(4000)
            .setRequired(false)
            .setPlaceholder('Enter the embed description...');

        const authorInput = new TextInputBuilder()
            .setCustomId('embed_author')
            .setLabel('Embed Author')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(256)
            .setRequired(false)
            .setPlaceholder('Enter the author name...');

        const thumbnailInput = new TextInputBuilder()
            .setCustomId('embed_thumbnail')
            .setLabel('Thumbnail URL')
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setPlaceholder('https://example.com/thumbnail.png');

        const imageInput = new TextInputBuilder()
            .setCustomId('embed_image')
            .setLabel('Main Image URL')
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setPlaceholder('https://example.com/image.png');

        // Add inputs to action rows (modals require action rows)
        const titleRow = new ActionRowBuilder().addComponents(titleInput);
        const descriptionRow = new ActionRowBuilder().addComponents(descriptionInput);
        const authorRow = new ActionRowBuilder().addComponents(authorInput);
        const thumbnailRow = new ActionRowBuilder().addComponents(thumbnailInput);
        const imageRow = new ActionRowBuilder().addComponents(imageInput);

        // Add rows to modal
        modal.addComponents(titleRow, descriptionRow, authorRow, thumbnailRow, imageRow);

        // Show modal to user
        await interaction.showModal(modal);
    }
};
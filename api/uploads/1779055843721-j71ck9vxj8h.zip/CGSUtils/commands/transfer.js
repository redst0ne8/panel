const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Function to update ticket status
function updateTicketStatus(client, channelId, newStatus, userId) {
    const ticketData = client.ticketManager.getTicket(channelId);
    if (!ticketData) return false;

    const oldStatus = ticketData.status || 'unclaimed';
    
    // Don't update if status hasn't changed
    if (oldStatus === newStatus) return false;

    // Initialize status history if it doesn't exist
    if (!ticketData.statusHistory) {
        ticketData.statusHistory = [];
    }

    // Add status change to history
    ticketData.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: newStatus,
        changedBy: userId,
        changedAt: Date.now()
    });

    // Update current status
    ticketData.status = newStatus;
    
    // Save the updated ticket data
    client.ticketManager.updateTicket(channelId, ticketData);
    
    return true;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('transfer')
        .setDescription('Transfer a ticket claim to another support representative')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to transfer the ticket to')
                .setRequired(true)
        ),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const ticketChannelId = interaction.channel.id;
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        const targetUser = interaction.options.getUser('user');
        
        // --- NEW/MODIFIED LOGIC START ---
        const claimedPrefix = '🟠';
        const isChannelClaimed = interaction.channel.name.startsWith(claimedPrefix);

        // Check if user has support role - REQUIRED FOR ALL USERS
        if (!interaction.member.roles.cache.has(supportRoleId)) {
            return await interaction.editReply({
                content: '❌ You need the support role to transfer tickets.'
            });
        }

        // Get ticket data
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.editReply({
                content: '❌ Ticket data not found.'
            });
        }

        // **MODIFIED CHECK:** Check if the channel is marked as claimed (🟠)
        // If the channel name starts with 🟠, we assume it is claimed and proceed.
        // We log a warning if the channel name and the ticketData disagree.
        if (!isChannelClaimed) {
             // If ticketData *also* says it's not claimed, use the original error message
            if (!ticketData.claimed) {
                 return await interaction.editReply({
                    content: '❌ This ticket is not currently claimed. Use the claim button instead.'
                });
            } else {
                // If ticketData says it's claimed, but channel name doesn't have 🟠, log warning and proceed
                console.warn(`[Transfer Command] Data Mismatch: Channel ${interaction.channel.name} is claimed in data but missing 🟠 prefix. Proceeding with transfer.`);
            }
        } else if (!ticketData.claimed) {
            // If channel name has 🟠, but ticketData says it's not claimed, log warning and proceed (this is the case you wanted to allow)
            console.warn(`[Transfer Command] Data Mismatch: Channel ${interaction.channel.name} has 🟠 prefix but is NOT claimed in data. Proceeding with transfer.`);
            
            // To prevent the next check from failing, we set dummy claim data if it's missing (should only happen if the claim data was lost)
            if (!ticketData.claimedById) {
                 // Use a generic ID or the user executing the command as a placeholder if no claimedById exists, just to pass the next check
                 ticketData.claimedById = interaction.user.id; 
                 ticketData.claimedBy = interaction.user.tag;
                 // Set claimed status to true so the transfer logic can flow correctly
                 ticketData.claimed = true;
            }
        }
        
        // ORIGINAL CHECK for ticketData.claimed (Now potentially bypassed/forced true if only 🟠 prefix is present, see above)
        // if (!ticketData.claimed) {
        //     return await interaction.editReply({
        //         content: '❌ This ticket is not currently claimed. Use the claim button instead.'
        //     });
        // }
        // --- NEW/MODIFIED LOGIC END ---

        // Check if user is the one who claimed the ticket or has admin permissions
        if (ticketData.claimedById !== interaction.user.id && !interaction.member.permissions.has('Administrator')) {
            return await interaction.editReply({
                content: `❌ Only the person who claimed this ticket (${ticketData.claimedBy}) or an administrator can transfer it.`
            });
        }
// ... rest of the code remains the same ...
        // The rest of the code for transferring the ticket, updating the embed, and logging remains the same.
        // I've omitted it here for brevity.
// ...
        const previousClaimedBy = ticketData.claimedBy;
        const previousClaimedById = ticketData.claimedById;

        // Update ticket data
        ticketData.claimedBy = targetUser.tag;
        ticketData.claimedById = targetUser.id;
        ticketData.transferredAt = Date.now();
        ticketData.transferredBy = interaction.user.tag;
        ticketData.transferredById = interaction.user.id;
        ticketData.transferredFrom = previousClaimedBy;

        // Initialize transfer history if it doesn't exist
        if (!ticketData.transferHistory) {
            ticketData.transferHistory = [];
        }

        // Add transfer to history
        ticketData.transferHistory.push({
            fromUser: previousClaimedBy,
            fromUserId: previousClaimedById,
            toUser: targetUser.tag,
            toUserId: targetUser.id,
            transferredBy: interaction.user.tag,
            transferredById: interaction.user.id,
            transferredAt: Date.now()
        });

        // Update status to claimed (maintaining claimed status but with new owner)
        updateTicketStatus(interaction.client, ticketChannelId, 'claimed', interaction.user.id);

        // Channel name stays the same (🟠 prefix for claimed status)
        const statusPrefix = '🟠';
        const currentChannelName = interaction.channel.name;
        let newChannelName;
        
        // Remove any existing status prefix and ensure it has the claimed prefix
        const cleanChannelName = currentChannelName.replace(/^[🟡🟠🔴🟢⚫🔵]\s*/, '');
        newChannelName = `${statusPrefix} ${cleanChannelName}`;
        
        try {
            if (currentChannelName !== newChannelName) {
                await interaction.channel.setName(newChannelName);
                console.log(`Channel name updated from "${currentChannelName}" to "${newChannelName}"`);
            }
        } catch (error) {
            console.error('Error updating channel name:', error);
        }

        // Save the updated ticket data
        interaction.client.ticketManager.updateTicket(ticketChannelId, ticketData);

        // Update the welcome embed
        try {
            const welcomeMessage = await interaction.channel.messages.fetch(ticketData.welcomeMessageId);
            const originalEmbed = welcomeMessage.embeds[0];
            
            const updatedEmbed = new EmbedBuilder()
                .setTitle(originalEmbed.title)
                .setDescription(originalEmbed.description)
                .setColor('#FFA500') // Orange color for claimed status
                .setTimestamp() // Use current timestamp instead
                .setThumbnail(originalEmbed.thumbnail?.url)
                .setFooter(originalEmbed.footer)
                .setFields(
                    { name: '📋 Ticket Type', value: ticketData.ticketType, inline: true },
                    { name: '👤 Created by', value: `<@${ticketData.userId}>`, inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: `🟠 Claimed by ${targetUser.tag}`, inline: true },
                    { name: '🔄 Transferred at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                );

            // Update buttons - disable claim button with new owner
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannelId}`)
                .setLabel(`Claimed by ${targetUser.username}`)
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('✅')
                .setDisabled(true);

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannelId}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            await welcomeMessage.edit({
                embeds: [updatedEmbed],
                components: [buttonRow]
            });

            // Send transfer message
            const transferEmbed = new EmbedBuilder()
                .setTitle('🔄 Ticket Transferred')
                .setDescription(`This ticket has been transferred from ${interaction.user} to ${targetUser}`)
                .addFields([
                    { name: '👤 Previous Owner', value: previousClaimedBy, inline: true },
                    { name: '👤 New Owner', value: targetUser.tag, inline: true },
                    { name: '🔄 Transferred by', value: interaction.user.tag, inline: true },
                    { name: '📊 Status', value: '🟠 Claimed', inline: true },
                    { name: '⏰ Transferred at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                ])
                .setColor('#FFA500')
                .setTimestamp();

            await interaction.channel.send({ embeds: [transferEmbed] });

            // Log to log channel
            const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🔄 Ticket Transferred')
                    .setDescription('A ticket has been transferred')
                    .addFields([
                        { name: '🎫 Ticket', value: `${interaction.channel} (${ticketChannelId})`, inline: true },
                        { name: '👤 Previous Owner', value: `${previousClaimedBy} (${previousClaimedById})`, inline: true },
                        { name: '👤 New Owner', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                        { name: '🔄 Transferred by', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                        { name: '📋 Type', value: ticketData.ticketType, inline: true },
                        { name: '📊 Status', value: '🟠 Claimed', inline: true }
                    ])
                    .setColor('#FFA500')
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

            console.log(`Ticket ${ticketChannelId} transferred from ${previousClaimedBy} (${previousClaimedById}) to ${targetUser.tag} (${targetUser.id}) by ${interaction.user.tag} (${interaction.user.id})`);

            await interaction.editReply({
                content: `✅ Ticket transferred successfully from **${previousClaimedBy}** to **${targetUser.tag}**!`
            });

        } catch (error) {
            console.error('Error transferring ticket:', error);
            await interaction.editReply({
                content: '❌ Error transferring ticket. Please try again.'
            });
        }
    }
};
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add')
        .setDescription('Add a user or role to the current channel')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to add to the channel')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to add to the channel')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        try {
            // Get the user and role options
            const targetUser = interaction.options.getUser('user');
            const targetRole = interaction.options.getRole('role');

            // Check if at least one option was provided
            if (!targetUser && !targetRole) {
                return await interaction.editReply({
                    content: '❌ Please specify either a user or a role to add to the channel.',
                });
            }

            const channel = interaction.channel;
            const addedTargets = [];
            const alreadyAdded = [];
            const errors = [];

            // Add user if specified
            if (targetUser) {
                try {
                    // Check if user already has access
                    const existingPermissions = channel.permissionOverwrites.cache.get(targetUser.id);
                    if (existingPermissions && existingPermissions.allow.has(PermissionFlagsBits.ViewChannel)) {
                        alreadyAdded.push(`👤 ${targetUser.displayName}`);
                    } else {
                        // Add user permissions
                        await channel.permissionOverwrites.edit(targetUser.id, {
                            ViewChannel: true,
                            SendMessages: true,
                            ReadMessageHistory: true,
                            AttachFiles: true,
                            EmbedLinks: true,
                            UseExternalEmojis: true,
                            AddReactions: true
                        });
                        addedTargets.push(`👤 ${targetUser.displayName}`);
                    }
                } catch (error) {
                    console.error('Error adding user to channel:', error);
                    errors.push(`Failed to add user ${targetUser.displayName}: ${error.message}`);
                }
            }

            // Add role if specified
            if (targetRole) {
                try {
                    // Check if role already has access
                    const existingPermissions = channel.permissionOverwrites.cache.get(targetRole.id);
                    if (existingPermissions && existingPermissions.allow.has(PermissionFlagsBits.ViewChannel)) {
                        alreadyAdded.push(`🏷️ @${targetRole.name}`);
                    } else {
                        // Add role permissions
                        await channel.permissionOverwrites.edit(targetRole.id, {
                            ViewChannel: true,
                            SendMessages: true,
                            ReadMessageHistory: true,
                            AttachFiles: true,
                            EmbedLinks: true,
                            UseExternalEmojis: true,
                            AddReactions: true
                        });
                        addedTargets.push(`🏷️ @${targetRole.name}`);
                    }
                } catch (error) {
                    console.error('Error adding role to channel:', error);
                    errors.push(`Failed to add role @${targetRole.name}: ${error.message}`);
                }
            }

            // Build response message
            let responseMessage = '';

            if (addedTargets.length > 0) {
                responseMessage += `✅ **Successfully added to channel:**\n${addedTargets.join('\n')}\n`;
            }

            if (alreadyAdded.length > 0) {
                responseMessage += `ℹ️ **Already had access:**\n${alreadyAdded.join('\n')}\n`;
            }

            if (errors.length > 0) {
                responseMessage += `❌ **Errors:**\n${errors.join('\n')}\n`;
            }

            if (!responseMessage) {
                responseMessage = '❌ No changes were made.';
            }

            await interaction.editReply({
                content: responseMessage.trim()
            });

            // Send notification to the channel (if someone was successfully added)
            if (addedTargets.length > 0) {
                const notificationTargets = [];
                if (targetUser && addedTargets.some(target => target.includes(targetUser.displayName))) {
                    notificationTargets.push(`<@${targetUser.id}>`);
                }
                if (targetRole && addedTargets.some(target => target.includes(targetRole.name))) {
                    notificationTargets.push(`<@&${targetRole.id}>`);
                }

                if (notificationTargets.length > 0) {
                    await channel.send({
                        content: `📢 ${notificationTargets.join(' and ')} ${notificationTargets.length === 1 ? 'has' : 'have'} been added to this channel by <@${interaction.user.id}>.`
                    });
                }
            }

        } catch (error) {
            console.error('Error in add command:', error);
            await interaction.editReply({
                content: '❌ An unexpected error occurred while trying to add the user/role to the channel.'
            });
        }
    },
};
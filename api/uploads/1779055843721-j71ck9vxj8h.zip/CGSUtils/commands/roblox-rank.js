import { SlashCommandBuilder } from 'discord.js';
import noblox from 'noblox.js';
import 'dotenv/config'; // Used to load environment variables

// --- Configuration ---
// These should be configured in your .env file
const ROBLOX_GROUP_ID = process.env.ROBLOX_GROUP_ID;
const ROBLOX_COOKIE = process.env.ROBLOX_COOKIE; // The .ROBLOSECURITY cookie

let isRobloxAuthenticated = false;

// --- Roblox Setup and Login ---
async function robloxLogin() {
    if (isRobloxAuthenticated) return;
    if (!ROBLOX_COOKIE || !ROBLOX_GROUP_ID) {
        console.error("Roblox Login Error: Missing ROBLOX_COOKIE or ROBLOX_GROUP_ID in environment variables. Group functions will not work.");
        return;
    }

    try {
        // setCookie historically returned a numeric userId, but newer versions
        // may return an object. Handle both cases robustly.
        const setCookieResult = await noblox.setCookie(ROBLOX_COOKIE);

        let currentUserId;
        let currentUserName;

        if (setCookieResult && typeof setCookieResult === 'object') {
            // Try common property names that may contain the ID/username
            currentUserId = setCookieResult.userId ?? setCookieResult.UserId ?? setCookieResult.id ?? setCookieResult.Id;
            currentUserName = setCookieResult.username ?? setCookieResult.Username ?? setCookieResult.userName;
        } else {
            currentUserId = setCookieResult;
        }

        // If username wasn't provided by the setCookie result, fetch it.
        if (!currentUserName && typeof currentUserId !== 'undefined') {
            currentUserName = await noblox.getUsernameFromId(currentUserId);
        }

        console.log(`[Roblox] Bot successfully logged in as ${currentUserName} (${currentUserId}).`);

        // Ensure group id is numeric when calling noblox functions
        const groupIdNumeric = Number(ROBLOX_GROUP_ID);
        if (Number.isNaN(groupIdNumeric)) {
            console.warn(`[Roblox] Invalid ROBLOX_GROUP_ID="${ROBLOX_GROUP_ID}" in environment; expected a numeric group id.`);
        } else {
            const rank = await noblox.getRankInGroup(groupIdNumeric, currentUserId);
            console.log(`[Roblox] Bot's rank in Group ID ${groupIdNumeric}: ${rank}.`);
        }

        isRobloxAuthenticated = true;
    } catch (error) {
        console.error("[Roblox] Noblox Login Error: Failed to set cookie or verify rank.", (error && error.message) || error);
        console.error("Please ensure the .ROBLOSECURITY cookie is valid, the bot account is a **MEMBER** of the group, and has the necessary permissions.");
        isRobloxAuthenticated = false;
    }
}

// Authenticate with Roblox as soon as this script is loaded
robloxLogin();


// --- Command Definition (data) ---
export const data = new SlashCommandBuilder()
    .setName('roblox')
    .setDescription('Manage user ranks and status in the configured Roblox group.')
    .addSubcommand(subcommand =>
        subcommand
            .setName('setrank')
            .setDescription('Sets a specific rank for a user.')
            .addStringOption(option =>
                option.setName('username')
                    .setDescription('The Roblox username.')
                    .setRequired(true))
            .addIntegerOption(option =>
                option.setName('rankid')
                    .setDescription('The numerical rank ID (RoleSetId) to set.')
                    .setRequired(true))
    );

// --- Command Execution (execute) ---
export async function execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const username = interaction.options.getString('username');

    // Defer the reply right away, as Roblox API calls can take time
    await interaction.deferReply();

    if (!isRobloxAuthenticated) {
        return interaction.editReply({ 
            content: "❌ **Roblox API Error:** The bot is not authenticated. Please check the ROBLOX_COOKIE in the `.env` file and restart the bot.",
            ephemeral: true
        });
    }

    try {
        // 1. Convert Username to User ID
        const userId = await noblox.getIdFromUsername(username);
        
        if (!userId) {
            return interaction.editReply(`❌ User not found: Could not find Roblox user ID for username \`${username}\`.`);
        }

        let responseMessage = '';
        let newRole = null;

        // --- Execute Subcommands ---
        switch (subcommand) {
            case 'promote':
                newRole = await noblox.promote(ROBLOX_GROUP_ID, userId);
                responseMessage = `✅ Successfully **promoted** \`${username}\` (ID: ${userId}) to rank: **${newRole.name}**!`;
                break;

            case 'demote':
                newRole = await noblox.demote(ROBLOX_GROUP_ID, userId);
                responseMessage = `✅ Successfully **demoted** \`${username}\` (ID: ${userId}) to rank: **${newRole.name}**!`;
                break;

            case 'setrank':
                const rankId = interaction.options.getInteger('rankid');
                if (rankId < 1) {
                    return interaction.editReply(`❌ Invalid Rank ID: Rank ID must be a positive integer.`);
                }
                newRole = await noblox.setRank(ROBLOX_GROUP_ID, userId, rankId);
                responseMessage = `✅ Successfully set \`${username}\` (ID: ${userId}) rank to **${newRole.name}** (ID: ${newRole.id}).`;
                break;

            case 'kick':
                await noblox.exile(ROBLOX_GROUP_ID, userId);
                responseMessage = `✅ Successfully **kicked** (exiled) \`${username}\` (ID: ${userId}) from the group.`;
                break;
                
            default:
                responseMessage = '❓ Unknown group management command.';
        }

        await interaction.editReply(responseMessage);

    } catch (error) {
        console.error(`Roblox command execution failed for /roblox ${subcommand}:`, error);
        
        // Clean up the error message for the Discord response
        let userFacingError = error.message;
        if (userFacingError.includes('Not Authorized') || userFacingError.includes('Insufficient role')) {
            userFacingError = "The bot does not have permission, or the target rank is higher than the bot's rank.";
        } else if (userFacingError.includes('Invalid parameter')) {
            userFacingError = "The provided Roblox username was invalid, or the user is not in the group.";
        }

        await interaction.editReply(`❌ **Operation Failed:** ${userFacingError}\n*Check bot permissions and target user's current status.*`);
    }
}
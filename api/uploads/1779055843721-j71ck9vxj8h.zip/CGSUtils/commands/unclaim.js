const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Function to update ticket status
function updateTicketStatus(client, channelId, newStatus, userId) {
    const ticketData = client.ticketManager.getTicket(channelId);
    if (!ticketData) return false;

    const oldStatus = ticketData.status || 'unclaimed';
    
    // Don't update if status hasn't changed
    if (oldStatus === newStatus) return false;

    // Initialize status history if it doesn't exist
    if (!ticketData.statusHistory) {
        ticketData.statusHistory = [];
    }

    // Add status change to history
    ticketData.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: newStatus,
        changedBy: userId,
        changedAt: Date.now()
    });

    // Update current status
    ticketData.status = newStatus;
    
    // Save the updated ticket data
    client.ticketManager.updateTicket(channelId, ticketData);
    
    return true;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unclaim')
        .setDescription('Unclaim a ticket and allow all support representatives to respond'),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const ticketChannelId = interaction.channel.id;
        const supportRoleId = '1400261853220962486';
        const forceUnclaimRoleId = '1396878222192541858'; // Role that can force unclaim any ticket
        const ticketLogChannelId = '1406342065486430350';
        
        // Check if user has support role - REQUIRED FOR ALL USERS
        if (!interaction.member.roles.cache.has(supportRoleId)) {
            return await interaction.editReply({
                content: '❌ You need the support role to unclaim tickets.'
            });
        }

        // Check if this is a ticket channel (by category ID)
        const ticketCategoryId = '1396877117647753227';
        if (interaction.channel.parentId !== ticketCategoryId) {
            return await interaction.editReply({
                content: '❌ This command can only be used in ticket channels.'
            });
        }

        // Get ticket data
        const ticketData = interaction.client.ticketManager.getTicket(ticketChannelId);
        if (!ticketData) {
            return await interaction.editReply({
                content: '❌ Ticket data not found.'
            });
        }

        if (!ticketData.claimed) {
            return await interaction.editReply({
                content: '❌ This ticket is not currently claimed.'
            });
        }

        // Check permissions: original claimer, admin, or force unclaim role
        const hasForceUnclaimRole = interaction.member.roles.cache.has(forceUnclaimRoleId);
        const isOriginalClaimer = ticketData.claimedById === interaction.user.id;
        const isAdmin = interaction.member.permissions.has('Administrator');
        
        if (!isOriginalClaimer && !isAdmin && !hasForceUnclaimRole) {
            return await interaction.editReply({
                content: `❌ Only the person who claimed this ticket (${ticketData.claimedBy}), an administrator, or users with force unclaim permissions can unclaim it.`
            });
        }

        const previousClaimedBy = ticketData.claimedBy;
        const isForceUnclaim = !isOriginalClaimer; // If not the original claimer, it's a force unclaim

        // Update ticket data
        ticketData.claimed = false;
        ticketData.claimedBy = null;
        ticketData.claimedById = null;
        ticketData.unclaimedAt = Date.now();
        ticketData.unclaimedBy = interaction.user.tag;
        ticketData.unclaimedById = interaction.user.id;

        // Update status to unclaimed and track status change
        updateTicketStatus(interaction.client, ticketChannelId, 'unclaimed', interaction.user.id);

        // Update channel name with status indicator
        const statusPrefix = '🟡';
        const currentChannelName = interaction.channel.name;
        let newChannelName;
        
        // Remove any existing status prefix
        const cleanChannelName = currentChannelName.replace(/^[🟡🟠🔴🟢⚫🔵]\s*/, '');
        newChannelName = `${statusPrefix} ${cleanChannelName}`;
        
        try {
            await interaction.channel.setName(newChannelName);
            console.log(`Channel name updated from "${currentChannelName}" to "${newChannelName}"`);
        } catch (error) {
            console.error('Error updating channel name:', error);
        }

        // Save the updated ticket data
        interaction.client.ticketManager.updateTicket(ticketChannelId, ticketData);

        // Update the welcome embed
        try {
            const welcomeMessage = await interaction.channel.messages.fetch(ticketData.welcomeMessageId);
            const originalEmbed = welcomeMessage.embeds[0];
            
            const updatedEmbed = new EmbedBuilder()
                .setTitle(originalEmbed.title)
                .setDescription(originalEmbed.description)
                .setColor('#FFFF00') // Yellow color for unclaimed status
                .setTimestamp() // Use current timestamp instead
                .setThumbnail(originalEmbed.thumbnail?.url)
                .setFooter(originalEmbed.footer)
                .setFields(
                    { name: '📋 Ticket Type', value: ticketData.ticketType, inline: true },
                    { name: '👤 Created by', value: `<@${ticketData.userId}>`, inline: true },
                    { name: '🕐 Created at', value: `<t:${Math.floor(ticketData.createdAt / 1000)}:F>`, inline: true },
                    { name: '🏷️ Status', value: `🟡 Unclaimed`, inline: true },
                    { name: '⏰ Unclaimed at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                );

            // Update buttons - enable claim button
            const claimButton = new ButtonBuilder()
                .setCustomId(`claim_ticket_${ticketChannelId}`)
                .setLabel('Claim Ticket')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('✋')
                .setDisabled(false);

            const closeButton = new ButtonBuilder()
                .setCustomId(`close_ticket_${ticketChannelId}`)
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒');

            const buttonRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

            await welcomeMessage.edit({
                embeds: [updatedEmbed],
                components: [buttonRow]
            });

            // Send unclaim message with different text for force unclaims
            const unclaimTitle = isForceUnclaim ? '🔓 Ticket Force Unclaimed' : '🔓 Ticket Unclaimed';
            const unclaimDescription = isForceUnclaim 
                ? `This ticket has been force unclaimed by ${interaction.user}` 
                : `This ticket has been unclaimed by ${interaction.user}`;

            const unclaimEmbed = new EmbedBuilder()
                .setTitle(unclaimTitle)
                .setDescription(unclaimDescription)
                .addFields([
                    { name: '📊 Previous Status', value: `🟠 Claimed by ${previousClaimedBy}`, inline: true },
                    { name: '📊 Current Status', value: '🟡 Unclaimed', inline: true },
                    { name: '⏰ Unclaimed at', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                ])
                .setColor('#FFFF00')
                .setTimestamp();

            await interaction.channel.send({ embeds: [unclaimEmbed] });

            // Log to log channel
            const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const logTitle = isForceUnclaim ? '🔓 Ticket Force Unclaimed' : '🔓 Ticket Unclaimed';
                const logDescription = isForceUnclaim 
                    ? 'A ticket has been force unclaimed' 
                    : 'A ticket has been unclaimed';

                const logEmbed = new EmbedBuilder()
                    .setTitle(logTitle)
                    .setDescription(logDescription)
                    .addFields([
                        { name: '🎫 Ticket', value: `${interaction.channel} (${ticketChannelId})`, inline: true },
                        { name: '👤 Unclaimed by', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                        { name: '👤 Previously claimed by', value: previousClaimedBy, inline: true },
                        { name: '📋 Type', value: ticketData.ticketType, inline: true },
                        { name: '📊 Status', value: '🟡 Unclaimed', inline: true }
                    ])
                    .setColor('#FFFF00')
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

            const actionType = isForceUnclaim ? 'force unclaimed' : 'unclaimed';
            console.log(`Ticket ${ticketChannelId} ${actionType} by ${interaction.user.tag} (${interaction.user.id}) - Status updated to unclaimed`);

            const successMessage = isForceUnclaim 
                ? '✅ Ticket force unclaimed successfully! Status updated to 🟡 Unclaimed' 
                : '✅ Ticket unclaimed successfully! Status updated to 🟡 Unclaimed';

            await interaction.editReply({
                content: successMessage
            });

        } catch (error) {
            console.error('Error unclaiming ticket:', error);
            await interaction.editReply({
                content: '❌ Error unclaiming ticket. Please try again.'
            });
        }
    }
};
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket-info')
        .setDescription('View information about the current ticket')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
    
    async execute(interaction) {
        try {
            const channel = interaction.channel;
            
            // Check if this is a ticket channel
            const ticketData = interaction.client.ticketManager.getTicket(channel.id);
            if (!ticketData) {
                return await interaction.reply({
                    content: '❌ This command can only be used in ticket channels.',
                    ephemeral: true
                });
            }
            
            // Create info embed
            const infoEmbed = new EmbedBuilder()
                .setTitle('🎫 Ticket Information')
                .setColor(0x0099FF)
                .setFooter({
                    text: 'CoasterTickets Support',
                    iconURL: interaction.client.user.displayAvatarURL()
                })
                .setTimestamp();
            
            // Basic ticket info
            const createdAt = ticketData.createdAt ? new Date(ticketData.createdAt) : null;
            const creator = ticketData.userId ? `<@${ticketData.userId}>` : 'Unknown';
            const claimedBy = ticketData.claimedBy ? `<@${ticketData.claimedBy}>` : 'Unclaimed';
            
            infoEmbed.addFields(
                { name: '👤 Created By', value: creator, inline: true },
                { name: '🛠️ Claimed By', value: claimedBy, inline: true },
                { name: '📅 Created At', value: createdAt ? `<t:${Math.floor(createdAt.getTime() / 1000)}:F>` : 'Unknown', inline: true }
            );
            
            // Current name info
            if (ticketData.originalName && ticketData.originalName !== channel.name) {
                infoEmbed.addFields(
                    { name: '📋 Original Name', value: `\`${ticketData.originalName}\``, inline: true },
                    { name: '🏷️ Current Name', value: `\`${channel.name}\``, inline: true }
                );
                
                if (ticketData.renamedBy) {
                    const renamedAt = ticketData.renamedAt ? new Date(ticketData.renamedAt) : null;
                    infoEmbed.addFields({
                        name: '🔄 Last Renamed',
                        value: `By <@${ticketData.renamedBy}>${renamedAt ? ` on <t:${Math.floor(renamedAt.getTime() / 1000)}:f>` : ''}`,
                        inline: false
                    });
                }
            }
            
            // Rename history
            if (ticketData.renameHistory && ticketData.renameHistory.length > 0) {
                const historyLimit = 5; // Show last 5 renames
                const recentHistory = ticketData.renameHistory.slice(-historyLimit);
                
                const historyText = recentHistory.map((rename, index) => {
                    const date = new Date(rename.renamedAt);
                    const timestamp = `<t:${Math.floor(date.getTime() / 1000)}:R>`;
                    return `**${index + 1}.** \`${rename.oldName}\` → \`${rename.newName}\`\n   By <@${rename.renamedBy}> ${timestamp}`;
                }).join('\n\n');
                
                infoEmbed.addFields({
                    name: `📝 Rename History ${ticketData.renameHistory.length > historyLimit ? `(Last ${historyLimit})` : ''}`,
                    value: historyText,
                    inline: false
                });
                
                if (ticketData.renameHistory.length > historyLimit) {
                    infoEmbed.addFields({
                        name: '📊 Total Renames',
                        value: `${ticketData.renameHistory.length}`,
                        inline: true
                    });
                }
            }
            
            // Status info with color circles
            function getStatusDisplay(status) {
                const statusMap = {
                    'unclaimed': '🟡 Unclaimed',
                    'claimed': '🟠 Claimed',
                    'escalated': '🔴 Awaiting HR',
                    'resolved': '🟢 Resolved',
                    'inactive': '⚫ Inactive',
                    'development': '🔵 Awaiting Developer'
                };
                return statusMap[status] || '🟡 Unclaimed';
            }
            
            const currentStatus = ticketData.status || 'unclaimed';
            let statusText = getStatusDisplay(currentStatus);
            
            // Add additional info based on status
            if (ticketData.closeRequest) {
                statusText += '\n*Close requested*';
            }
            
            infoEmbed.addFields({
                name: '📊 Status',
                value: statusText,
                inline: true
            });
            
            // Status history
            if (ticketData.statusHistory && ticketData.statusHistory.length > 0) {
                const historyLimit = 3; // Show last 3 status changes
                const recentStatusHistory = ticketData.statusHistory.slice(-historyLimit);
                
                const statusHistoryText = recentStatusHistory.map((statusChange, index) => {
                    const date = new Date(statusChange.changedAt);
                    const timestamp = `<t:${Math.floor(date.getTime() / 1000)}:R>`;
                    const fromStatus = getStatusDisplay(statusChange.fromStatus);
                    const toStatus = getStatusDisplay(statusChange.toStatus);
                    return `**${index + 1}.** ${fromStatus} → ${toStatus}\n   By <@${statusChange.changedBy}> ${timestamp}`;
                }).join('\n\n');
                
                infoEmbed.addFields({
                    name: `📈 Status History ${ticketData.statusHistory.length > historyLimit ? `(Last ${historyLimit})` : ''}`,
                    value: statusHistoryText,
                    inline: false
                });
                
                if (ticketData.statusHistory.length > historyLimit) {
                    infoEmbed.addFields({
                        name: '📊 Total Status Changes',
                        value: `${ticketData.statusHistory.length}`,
                        inline: true
                    });
                }
            }
            
            await interaction.reply({
                embeds: [infoEmbed],
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error executing ticket-info command:', error);
            await interaction.reply({
                content: '❌ An error occurred while fetching ticket information.',
                ephemeral: true
            });
        }
    }
};
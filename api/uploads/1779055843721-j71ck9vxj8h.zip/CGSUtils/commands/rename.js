const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rename')
        .setDescription('Rename a ticket channel')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('New name for the ticket')
                .setRequired(true)
                .setMinLength(1)
                .setMaxLength(100))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
    
    async execute(interaction) {
        // Defer reply to prevent timeout issues
        await interaction.deferReply();
        
        try {
            const newName = interaction.options.getString('name');
            const channel = interaction.channel;
            
            // Validate bot permissions
            if (!channel.permissionsFor(interaction.client.user).has(PermissionFlagsBits.ManageChannels)) {
                return await interaction.editReply({
                    content: '❌ I don\'t have permission to manage channels in this server.'
                });
            }
            
            // Check if ticketManager exists
            if (!interaction.client.ticketManager) {
                console.error('TicketManager not found on client');
                return await interaction.editReply({
                    content: '❌ Ticket system is not properly initialized.'
                });
            }
            
            // Check if this is a ticket channel
            const ticketData = interaction.client.ticketManager.getTicket(channel.id);
            if (!ticketData) {
                return await interaction.editReply({
                    content: '❌ This command can only be used in ticket channels.'
                });
            }
            
            // Validate and sanitize the new name
            const sanitizedName = sanitizeName(newName);
            if (!sanitizedName) {
                return await interaction.editReply({
                    content: '❌ Please provide a valid name. Names must contain at least one alphanumeric character.'
                });
            }
            
            // Check if the name is actually different
            if (sanitizedName === channel.name) {
                return await interaction.editReply({
                    content: '❌ The new name is the same as the current name.'
                });
            }
            
            // Store the old name for logging
            const oldName = channel.name;
            
            // Attempt to rename the channel
            try {
                await channel.setName(sanitizedName, `Ticket renamed by ${interaction.user.tag}`);
            } catch (error) {
                console.error('Error renaming channel:', error);
                
                // Handle specific Discord API errors
                if (error.code === 50013) {
                    return await interaction.editReply({
                        content: '❌ I don\'t have permission to rename this channel.'
                    });
                } else if (error.code === 50035) {
                    return await interaction.editReply({
                        content: '❌ The channel name is invalid. Please try a different name.'
                    });
                } else if (error.code === 429) {
                    return await interaction.editReply({
                        content: '❌ Rate limit exceeded. Please try again later.'
                    });
                } else {
                    return await interaction.editReply({
                        content: '❌ Failed to rename the ticket channel. Please try again later.'
                    });
                }
            }
            
            // Initialize rename history if it doesn't exist
            if (!ticketData.renameHistory) {
                ticketData.renameHistory = [];
            }
            
            // Add to rename history
            ticketData.renameHistory.push({
                oldName: oldName,
                newName: sanitizedName,
                renamedBy: interaction.user.id,
                renamedAt: Date.now()
            });
            
            // Update ticket data with new name
            const updatedTicketData = {
                ...ticketData,
                channelName: sanitizedName,
                renamedBy: interaction.user.id,
                renamedAt: Date.now(),
                originalName: ticketData.originalName || oldName
            };
            
            // Save updated ticket data with error handling
            try {
                interaction.client.ticketManager.updateTicket(channel.id, updatedTicketData);
            } catch (updateError) {
                console.error('Error updating ticket data:', updateError);
                // Continue execution even if data update fails
            }
            
            // Create success embed
            const successEmbed = new EmbedBuilder()
                .setTitle('🏷️ Ticket Renamed')
                .setDescription('This ticket has been renamed successfully!')
                .addFields(
                    { name: '📋 Previous Name', value: `\`${oldName}\``, inline: true },
                    { name: '🆕 New Name', value: `\`${sanitizedName}\``, inline: true },
                    { name: '👤 Renamed By', value: `<@${interaction.user.id}>`, inline: true }
                )
                .setColor(0x00FF88)
                .setFooter({
                    text: 'CoasterTickets Support',
                    iconURL: interaction.client.user.displayAvatarURL()
                })
                .setTimestamp();
            
            // Send confirmation
            await interaction.editReply({
                embeds: [successEmbed]
            });
            
            // Log the rename action
            console.log(`[RENAME] Ticket ${channel.id} renamed from "${oldName}" to "${sanitizedName}" by ${interaction.user.tag} (${interaction.user.id})`);
            
        } catch (error) {
            console.error('Unexpected error in rename command:', error);
            
            // Try to respond if we haven't already
            try {
                if (interaction.deferred) {
                    await interaction.editReply({
                        content: '❌ An unexpected error occurred while renaming the ticket. Please try again later.'
                    });
                } else {
                    await interaction.reply({
                        content: '❌ An unexpected error occurred while renaming the ticket. Please try again later.',
                        ephemeral: true
                    });
                }
            } catch (replyError) {
                console.error('Failed to send error message:', replyError);
            }
        }
    }
};

/**
 * Sanitize channel name to meet Discord requirements
 * @param {string} name - Raw name input
 * @returns {string|null} - Sanitized name or null if invalid
 */
function sanitizeName(name) {
    if (!name || typeof name !== 'string') return null;
    
    // Trim whitespace
    let sanitized = name.trim();
    
    if (sanitized.length === 0) return null;
    
    // Convert to lowercase
    sanitized = sanitized.toLowerCase();
    
    // Replace invalid characters with dashes
    // Discord allows: a-z, 0-9, hyphens, underscores
    sanitized = sanitized.replace(/[^a-z0-9\-_]/g, '-');
    
    // Remove multiple consecutive dashes/underscores
    sanitized = sanitized.replace(/[-_]{2,}/g, '-');
    
    // Remove leading/trailing dashes and underscores
    sanitized = sanitized.replace(/^[-_]+|[-_]+$/g, '');
    
    // Ensure it's not empty after cleaning
    if (sanitized.length === 0) return null;
    
    // Truncate if too long (Discord limit is 100 characters)
    if (sanitized.length > 100) {
        sanitized = sanitized.substring(0, 100);
        // Remove trailing dashes after truncation
        sanitized = sanitized.replace(/[-_]+$/, '');
    }
    
    // Final check - must have at least one character
    return sanitized.length > 0 ? sanitized : null;
}
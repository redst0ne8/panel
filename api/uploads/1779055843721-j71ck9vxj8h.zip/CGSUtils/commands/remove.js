const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove')
        .setDescription('Remove a user from the ticket')
        .addUserOption(option =>
            option
                .setName('user')
                .setDescription('The user to remove from the ticket')
                .setRequired(true)
        ),
    
    async execute(interaction) {
        const supportRoleId = '1400261853220962486';
        const ticketLogChannelId = '1406342065486430350';
        
        // Check if user has support role
        const hasSupport = interaction.member.roles.cache.has(supportRoleId);
        
        if (!hasSupport) {
            return await interaction.reply({
                content: '❌ Only support staff can remove users from tickets.',
                ephemeral: true
            });
        }

        // Check if this is a ticket channel
        const ticketData = interaction.client.ticketManager.getTicket(interaction.channel.id);
        if (!ticketData) {
            return await interaction.reply({
                content: '❌ This command can only be used in ticket channels.',
                ephemeral: true
            });
        }

        const userToRemove = interaction.options.getUser('user');
        const memberToRemove = interaction.guild.members.cache.get(userToRemove.id);

        if (!memberToRemove) {
            return await interaction.reply({
                content: '❌ User not found in this server.',
                ephemeral: true
            });
        }

        // Prevent removing the ticket owner
        if (userToRemove.id === ticketData.userId) {
            return await interaction.reply({
                content: '❌ You cannot remove the ticket owner from their own ticket.',
                ephemeral: true
            });
        }

        // Prevent removing yourself if you're the only support staff
        if (userToRemove.id === interaction.user.id) {
            return await interaction.reply({
                content: '❌ You cannot remove yourself from the ticket.',
                ephemeral: true
            });
        }

        try {
            // Remove view permissions for the user
            await interaction.channel.permissionOverwrites.edit(userToRemove.id, {
                ViewChannel: false,
                SendMessages: false,
                ReadMessageHistory: false
            });

            // Create removal embed
            const removeEmbed = new EmbedBuilder()
                .setTitle('👋 User Removed from Ticket')
                .setDescription(`${userToRemove.tag} has been removed from this ticket by ${interaction.user.tag}`)
                .setColor('#ff0000')
                .setTimestamp()
                .setThumbnail(userToRemove.displayAvatarURL({ dynamic: true }));

            await interaction.reply({
                embeds: [removeEmbed]
            });

            // Log the removal
            const logChannel = interaction.guild.channels.cache.get(ticketLogChannelId);
            if (logChannel) {
                const ticketOwner = await interaction.client.users.fetch(ticketData.userId);

                const logEmbed = new EmbedBuilder()
                    .setTitle('👋 User Removed from Ticket')
                    .addFields([
                        { name: '👤 Ticket Owner', value: `${ticketOwner.tag} (${ticketOwner.id})`, inline: true },
                        { name: '🚫 Removed User', value: `${userToRemove.tag} (${userToRemove.id})`, inline: true },
                        { name: '👮 Removed By', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                        { name: '🆔 Ticket ID', value: interaction.channel.id, inline: false },
                        { name: '📋 Ticket Type', value: ticketData.ticketType, inline: true }
                    ])
                    .setColor('#ff0000')
                    .setTimestamp()
                    .setThumbnail(userToRemove.displayAvatarURL({ dynamic: true }));

                await logChannel.send({ embeds: [logEmbed] });
            }

        } catch (error) {
            console.error('Error removing user from ticket:', error);
            await interaction.reply({
                content: '❌ An error occurred while removing the user from the ticket.',
                ephemeral: true
            });
        }
    }
};